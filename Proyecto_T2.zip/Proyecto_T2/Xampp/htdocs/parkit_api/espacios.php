<?php

include 'conexion.php';
include 'vencer_reservas.php';

// la accion llega en la url (ej: espacios.php?accion=listar)
$accion =isset($_GET['accion']) ? $_GET['accion'] : '';

switch($accion){
    case 'listar':
        accion_listar($conexion);
        break;
    case 'control':
        accion_control($conexion);
        break;
    default:
        echo "accion no valida";
}

function accion_listar($conexion){

    $id =intval($_POST['id_estacionamiento']);

    $result =array();
    $result['datos'] =array();

    $stmt =mysqli_prepare($conexion,"SELECT id_espacio,codigo,estado FROM espacios WHERE id_estacionamiento=? ORDER BY codigo");
    mysqli_stmt_bind_param($stmt,"i",$id);
    mysqli_stmt_execute($stmt);
    $responce =mysqli_stmt_get_result($stmt);

    while($row =mysqli_fetch_array($responce))
    {
        $index['id_espacio'] =$row['0'];
        $index['codigo'] =$row['1'];
        $index['estado'] =$row['2'];

        array_push($result['datos'], $index);
    }
    $result["exito"]="1";
    echo json_encode($result);

    mysqli_close($conexion);

}

function accion_control($conexion){

    $id_usuario =intval($_POST['id_usuario']);

    $result =array();
    $result['datos'] =array();

    // solo el encargado ve los espacios de su estacionamiento
    $stmt =mysqli_prepare($conexion,"SELECT id_estacionamiento FROM estacionamientos WHERE id_encargado=?");
    mysqli_stmt_bind_param($stmt,"i",$id_usuario);
    mysqli_stmt_execute($stmt);
    $row =mysqli_fetch_array(mysqli_stmt_get_result($stmt));
    if(!$row){
        $result['exito'] ="0";
        $result['mensaje'] ="no tiene un estacionamiento a cargo";
        echo json_encode($result);
        exit;
    }
    $id_estacionamiento =$row['0'];

    // cada espacio con su reserva activa (si la tiene) y la hora de ingreso
    $query ="SELECT e.id_espacio,e.codigo,e.estado,
                    IFNULL(r.id_reserva,''),IFNULL(v.placa,''),IFNULL(CONCAT(u.nombre,' ',u.apellido),''),
                    IFNULL(TIME_FORMAT(r.hora_inicio,'%H:%i'),''),IFNULL(TIME_FORMAT(r.hora_fin,'%H:%i'),''),
                    IFNULL(r.estado,''),IFNULL(r.monto,''),
                    IFNULL((SELECT DATE_FORMAT(m.hora_ingreso,'%H:%i') FROM movimientos m WHERE m.id_reserva=r.id_reserva AND m.hora_salida IS NULL LIMIT 1),'')
             FROM espacios e
             LEFT JOIN reservas r ON r.id_espacio=e.id_espacio AND r.estado IN ('pendiente','confirmada','en_curso')
             LEFT JOIN vehiculos v ON v.id_vehiculo=r.id_vehiculo
             LEFT JOIN usuarios u ON u.id_usuario=r.id_usuario
             WHERE e.id_estacionamiento=?
             ORDER BY e.codigo";
    $stmt =mysqli_prepare($conexion,$query);
    mysqli_stmt_bind_param($stmt,"i",$id_estacionamiento);
    mysqli_stmt_execute($stmt);
    $responce =mysqli_stmt_get_result($stmt);

    while($row =mysqli_fetch_array($responce))
    {
        $index['id_espacio'] =$row['0'];
        $index['codigo'] =$row['1'];
        $index['estado'] =$row['2'];
        $index['id_reserva'] =$row['3'];
        $index['placa'] =$row['4'];
        $index['conductor'] =$row['5'];
        $index['hora_inicio'] =$row['6'];
        $index['hora_fin'] =$row['7'];
        $index['estado_reserva'] =$row['8'];
        $index['monto'] =$row['9'];
        $index['ingreso'] =$row['10'];

        array_push($result['datos'], $index);
    }
    $result["exito"]="1";
    echo json_encode($result);

    mysqli_close($conexion);

}

?>

<?php

include 'conexion.php';
include 'vencer_reservas.php';

// la accion llega en la url (ej: notificaciones.php?accion=listar)
$accion =isset($_GET['accion']) ? $_GET['accion'] : '';

switch($accion){
    case 'listar':
        accion_listar($conexion);
        break;
    default:
        echo "accion no valida";
}

function accion_listar($conexion){

    $id_usuario =intval($_POST['id_usuario']);
    $contar =isset($_POST['contar']) ? $_POST['contar'] : '';

    $result =array();

    // con contar=1 solo se devuelve cuantas alertas no se han leido
    if($contar=="1"){
        $stmt =mysqli_prepare($conexion,"SELECT COUNT(*) FROM notificaciones WHERE id_usuario=? AND leida=0");
        mysqli_stmt_bind_param($stmt,"i",$id_usuario);
        mysqli_stmt_execute($stmt);
        $row =mysqli_fetch_array(mysqli_stmt_get_result($stmt));

        $result['sin_leer'] =$row['0'];
        $result['exito'] ="1";
        echo json_encode($result);
        mysqli_close($conexion);
        exit;
    }

    $result['datos'] =array();

    $stmt =mysqli_prepare($conexion,"SELECT id_notificacion,titulo,mensaje,DATE_FORMAT(fecha,'%d/%m/%Y %H:%i'),leida FROM notificaciones WHERE id_usuario=? ORDER BY id_notificacion DESC");
    mysqli_stmt_bind_param($stmt,"i",$id_usuario);
    mysqli_stmt_execute($stmt);
    $responce =mysqli_stmt_get_result($stmt);

    while($row =mysqli_fetch_array($responce))
    {
        $index['id_notificacion'] =$row['0'];
        $index['titulo'] =$row['1'];
        $index['mensaje'] =$row['2'];
        $index['fecha'] =$row['3'];
        $index['leida'] =$row['4'];

        array_push($result['datos'], $index);
    }

    // al abrir la lista todas quedan como leidas
    $stmt =mysqli_prepare($conexion,"UPDATE notificaciones SET leida=1 WHERE id_usuario=?");
    mysqli_stmt_bind_param($stmt,"i",$id_usuario);
    mysqli_stmt_execute($stmt);

    $result["exito"]="1";
    echo json_encode($result);

    mysqli_close($conexion);

}

?>

<?php

include 'conexion.php';
include 'vencer_reservas.php';

// la accion llega en la url (ej: reservas.php?accion=insertar)
$accion =isset($_GET['accion']) ? $_GET['accion'] : '';

switch($accion){
    case 'insertar':
        accion_insertar($conexion);
        break;
    case 'listar':
        accion_listar($conexion);
        break;
    case 'obtener':
        accion_obtener($conexion);
        break;
    case 'confirmar':
        accion_confirmar($conexion);
        break;
    case 'cancelar':
        accion_cancelar($conexion);
        break;
    case 'metodos':
        accion_metodos($conexion);
        break;
    default:
        echo "accion no valida";
}

function accion_insertar($conexion){

    date_default_timezone_set('America/Lima');

    $id_usuario =intval($_POST['id_usuario']);
    $id_vehiculo =intval($_POST['id_vehiculo']);
    $id_espacio =intval($_POST['id_espacio']);
    $horas =intval($_POST['horas']);

    $result =array();

    if($id_usuario<=0 || $id_vehiculo<=0 || $id_espacio<=0 || $horas<1 || $horas>8){
        $result['exito'] ="0";
        $result['mensaje'] ="datos invalidos";
        echo json_encode($result);
        exit;
    }

    // el vehiculo debe ser de un conductor
    $stmt =mysqli_prepare($conexion,"SELECT v.id_vehiculo FROM vehiculos v INNER JOIN usuarios u ON u.id_usuario=v.id_usuario
                                     WHERE v.id_vehiculo=? AND v.id_usuario=? AND u.rol='conductor'");
    mysqli_stmt_bind_param($stmt,"ii",$id_vehiculo,$id_usuario);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);
    if(mysqli_stmt_num_rows($stmt)==0){
        $result['exito'] ="0";
        $result['mensaje'] ="vehiculo no valido";
        echo json_encode($result);
        exit;
    }

    // un vehiculo no puede tener dos reservas a la vez
    $stmt =mysqli_prepare($conexion,"SELECT id_reserva FROM reservas WHERE id_vehiculo=? AND estado IN ('pendiente','confirmada','en_curso')");
    mysqli_stmt_bind_param($stmt,"i",$id_vehiculo);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);
    if(mysqli_stmt_num_rows($stmt)>0){
        $result['exito'] ="0";
        $result['mensaje'] ="el vehiculo ya tiene una reserva activa";
        echo json_encode($result);
        exit;
    }

    $stmt =mysqli_prepare($conexion,"SELECT p.tarifa_hora FROM espacios e INNER JOIN estacionamientos p ON p.id_estacionamiento=e.id_estacionamiento
                                     WHERE e.id_espacio=?");
    mysqli_stmt_bind_param($stmt,"i",$id_espacio);
    mysqli_stmt_execute($stmt);
    $row =mysqli_fetch_array(mysqli_stmt_get_result($stmt));
    if(!$row){
        $result['exito'] ="0";
        $result['mensaje'] ="espacio no encontrado";
        echo json_encode($result);
        exit;
    }
    $monto =$row['0'] * $horas;

    $fecha =date('Y-m-d');
    $hora_inicio =date('H:i:s');
    $hora_fin =date('H:i:s', strtotime("+".$horas." hours"));

    mysqli_begin_transaction($conexion);

    // solo se reserva si sigue disponible (otro conductor pudo ganarle)
    $stmt =mysqli_prepare($conexion,"UPDATE espacios SET estado='reservado' WHERE id_espacio=? AND estado='disponible'");
    mysqli_stmt_bind_param($stmt,"i",$id_espacio);
    mysqli_stmt_execute($stmt);
    if(mysqli_stmt_affected_rows($stmt)!=1){
        mysqli_rollback($conexion);
        $result['exito'] ="0";
        $result['mensaje'] ="el espacio ya no esta disponible";
        echo json_encode($result);
        exit;
    }

    // el metodo de pago se elige al confirmar, por eso queda en NULL
    $query ="INSERT INTO reservas(id_usuario,id_vehiculo,id_espacio,id_metodo,fecha_reserva,hora_inicio,hora_fin,monto,estado)
             VALUES(?,?,?,NULL,?,?,?,?,'pendiente')";
    $stmt =mysqli_prepare($conexion,$query);
    mysqli_stmt_bind_param($stmt,"iiisssd",$id_usuario,$id_vehiculo,$id_espacio,$fecha,$hora_inicio,$hora_fin,$monto);

    if(mysqli_stmt_execute($stmt)){
        $result['id_reserva'] =strval(mysqli_insert_id($conexion));
        mysqli_commit($conexion);
        $result['exito'] ="1";
        $result['mensaje'] ="reserva registrada";
    }else{
        mysqli_rollback($conexion);
        $result['exito'] ="0";
        $result['mensaje'] ="error en registro";
    }

    echo json_encode($result);

    mysqli_close($conexion);

}

function accion_listar($conexion){

    $id_usuario =intval($_POST['id_usuario']);

    $result =array();
    $result['datos'] =array();

    $query ="SELECT r.id_reserva,p.nombre,e.codigo,v.placa,DATE_FORMAT(r.fecha_reserva,'%d/%m/%Y'),TIME_FORMAT(r.hora_inicio,'%H:%i'),TIME_FORMAT(r.hora_fin,'%H:%i'),r.monto,r.estado,IFNULL(m.nombre,'')
             FROM reservas r
             INNER JOIN espacios e ON e.id_espacio=r.id_espacio
             INNER JOIN estacionamientos p ON p.id_estacionamiento=e.id_estacionamiento
             INNER JOIN vehiculos v ON v.id_vehiculo=r.id_vehiculo
             LEFT JOIN metodos_pago m ON m.id_metodo=r.id_metodo
             WHERE r.id_usuario=?
             ORDER BY r.id_reserva DESC";
    $stmt =mysqli_prepare($conexion,$query);
    mysqli_stmt_bind_param($stmt,"i",$id_usuario);
    mysqli_stmt_execute($stmt);
    $responce =mysqli_stmt_get_result($stmt);

    while($row =mysqli_fetch_array($responce))
    {
        $index['id_reserva'] =$row['0'];
        $index['estacionamiento'] =$row['1'];
        $index['espacio'] =$row['2'];
        $index['placa'] =$row['3'];
        $index['fecha'] =$row['4'];
        $index['hora_inicio'] =$row['5'];
        $index['hora_fin'] =$row['6'];
        $index['monto'] =$row['7'];
        $index['estado'] =$row['8'];
        $index['metodo'] =$row['9'];

        array_push($result['datos'], $index);
    }
    $result["exito"]="1";
    echo json_encode($result);

    mysqli_close($conexion);

}

function accion_obtener($conexion){

    $id_usuario =intval($_POST['id_usuario']);
    $id_reserva =intval($_POST['id_reserva']);

    $result =array();

    $query ="SELECT r.id_reserva,p.nombre,e.codigo,v.placa,DATE_FORMAT(r.fecha_reserva,'%d/%m/%Y'),TIME_FORMAT(r.hora_inicio,'%H:%i'),TIME_FORMAT(r.hora_fin,'%H:%i'),r.monto,r.estado,IFNULL(m.nombre,'')
             FROM reservas r
             INNER JOIN espacios e ON e.id_espacio=r.id_espacio
             INNER JOIN estacionamientos p ON p.id_estacionamiento=e.id_estacionamiento
             INNER JOIN vehiculos v ON v.id_vehiculo=r.id_vehiculo
             LEFT JOIN metodos_pago m ON m.id_metodo=r.id_metodo
             WHERE r.id_reserva=? AND r.id_usuario=?";
    $stmt =mysqli_prepare($conexion,$query);
    mysqli_stmt_bind_param($stmt,"ii",$id_reserva,$id_usuario);
    mysqli_stmt_execute($stmt);
    $row =mysqli_fetch_array(mysqli_stmt_get_result($stmt));

    if($row){
        $index['id_reserva'] =$row['0'];
        $index['estacionamiento'] =$row['1'];
        $index['espacio'] =$row['2'];
        $index['placa'] =$row['3'];
        $index['fecha'] =$row['4'];
        $index['hora_inicio'] =$row['5'];
        $index['hora_fin'] =$row['6'];
        $index['monto'] =$row['7'];
        $index['estado'] =$row['8'];
        $index['metodo'] =$row['9'];

        $result['reserva'] =$index;
        $result['exito'] ="1";
    }else{
        $result['exito'] ="0";
        $result['mensaje'] ="reserva no encontrada";
    }

    echo json_encode($result);

    mysqli_close($conexion);

}

function accion_confirmar($conexion){

    $id_usuario =intval($_POST['id_usuario']);
    $id_reserva =intval($_POST['id_reserva']);
    $id_metodo =intval($_POST['id_metodo']);

    // el metodo de pago debe existir y estar activo
    $stmt =mysqli_prepare($conexion,"SELECT id_metodo FROM metodos_pago WHERE id_metodo=? AND activo=1");
    mysqli_stmt_bind_param($stmt,"i",$id_metodo);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);
    if(mysqli_stmt_num_rows($stmt)==0){
        echo "metodo de pago no valido";
        exit;
    }

    // solo se confirma una reserva propia que siga pendiente (el pago es simulado)
    $stmt =mysqli_prepare($conexion,"UPDATE reservas SET id_metodo=?, estado='confirmada' WHERE id_reserva=? AND id_usuario=? AND estado='pendiente'");
    mysqli_stmt_bind_param($stmt,"iii",$id_metodo,$id_reserva,$id_usuario);
    mysqli_stmt_execute($stmt);

    if(mysqli_stmt_affected_rows($stmt)!=1){
        echo "la reserva ya no se puede confirmar";
        exit;
    }

    $query ="INSERT INTO notificaciones(id_usuario,titulo,mensaje,tipo)
             SELECT r.id_usuario,'Reserva confirmada',
                    CONCAT('Espacio ',e.codigo,' en ',p.nombre,' de ',TIME_FORMAT(r.hora_inicio,'%H:%i'),' a ',TIME_FORMAT(r.hora_fin,'%H:%i')),'reserva'
             FROM reservas r
             INNER JOIN espacios e ON e.id_espacio=r.id_espacio
             INNER JOIN estacionamientos p ON p.id_estacionamiento=e.id_estacionamiento
             WHERE r.id_reserva=?";
    $stmt =mysqli_prepare($conexion,$query);
    mysqli_stmt_bind_param($stmt,"i",$id_reserva);
    mysqli_stmt_execute($stmt);

    echo "reserva confirmada";

    mysqli_close($conexion);

}

function accion_cancelar($conexion){

    $id_usuario =intval($_POST['id_usuario']);
    $id_reserva =intval($_POST['id_reserva']);

    mysqli_begin_transaction($conexion);

    // solo se cancela una reserva propia que este pendiente o confirmada
    $stmt =mysqli_prepare($conexion,"UPDATE reservas SET estado='cancelada' WHERE id_reserva=? AND id_usuario=? AND estado IN ('pendiente','confirmada')");
    mysqli_stmt_bind_param($stmt,"ii",$id_reserva,$id_usuario);
    mysqli_stmt_execute($stmt);

    if(mysqli_stmt_affected_rows($stmt)!=1){
        mysqli_rollback($conexion);
        echo "la reserva no se puede cancelar";
        exit;
    }

    // el espacio vuelve a estar libre
    $stmt =mysqli_prepare($conexion,"UPDATE espacios e INNER JOIN reservas r ON r.id_espacio=e.id_espacio
                                     SET e.estado='disponible' WHERE r.id_reserva=? AND e.estado='reservado'");
    mysqli_stmt_bind_param($stmt,"i",$id_reserva);
    mysqli_stmt_execute($stmt);

    $query ="INSERT INTO notificaciones(id_usuario,titulo,mensaje,tipo)
             SELECT r.id_usuario,'Reserva cancelada',
                    CONCAT('Se cancelo su reserva del espacio ',e.codigo,' en ',p.nombre),'reserva'
             FROM reservas r
             INNER JOIN espacios e ON e.id_espacio=r.id_espacio
             INNER JOIN estacionamientos p ON p.id_estacionamiento=e.id_estacionamiento
             WHERE r.id_reserva=?";
    $stmt =mysqli_prepare($conexion,$query);
    mysqli_stmt_bind_param($stmt,"i",$id_reserva);
    mysqli_stmt_execute($stmt);

    mysqli_commit($conexion);
    echo "reserva cancelada";

    mysqli_close($conexion);

}

function accion_metodos($conexion){

    $result =array();
    $result['datos'] =array();

    $responce =mysqli_query($conexion,"SELECT id_metodo,nombre FROM metodos_pago WHERE activo=1 ORDER BY id_metodo");

    while($row =mysqli_fetch_array($responce))
    {
        $index['id_metodo'] =$row['0'];
        $index['nombre'] =$row['1'];

        array_push($result['datos'], $index);
    }
    $result["exito"]="1";
    echo json_encode($result);

    mysqli_close($conexion);

}

?>

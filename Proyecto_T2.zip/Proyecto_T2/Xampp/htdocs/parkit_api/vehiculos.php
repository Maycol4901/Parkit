<?php

include 'conexion.php';

// la accion llega en la url (ej: vehiculos.php?accion=insertar)
$accion =isset($_GET['accion']) ? $_GET['accion'] : '';

switch($accion){
    case 'insertar':
        accion_insertar($conexion);
        break;
    case 'listar':
        accion_listar($conexion);
        break;
    case 'eliminar':
        accion_eliminar($conexion);
        break;
    default:
        echo "accion no valida";
}

function accion_insertar($conexion){

    $id_usuario =intval($_POST['id_usuario']);
    $placa =strtoupper(str_replace('-','',trim($_POST['placa'])));
    $marca =trim($_POST['marca']);
    $modelo =trim($_POST['modelo']);
    $color =trim($_POST['color']);
    $tipo =$_POST['tipo'];

    if($id_usuario<=0 || $marca=='' || $modelo=='' || $color=='' || !preg_match('/^[A-Z0-9]{6}$/',$placa) || !in_array($tipo,array('auto','camioneta','moto'))){
        echo "datos invalidos";
        exit;
    }

    // solo los conductores registran vehiculos
    $stmt =mysqli_prepare($conexion,"SELECT id_usuario FROM usuarios WHERE id_usuario=? AND rol='conductor'");
    mysqli_stmt_bind_param($stmt,"i",$id_usuario);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);
    if(mysqli_stmt_num_rows($stmt)==0){
        echo "usuario no autorizado";
        exit;
    }

    $stmt =mysqli_prepare($conexion,"SELECT id_vehiculo FROM vehiculos WHERE placa=?");
    mysqli_stmt_bind_param($stmt,"s",$placa);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);
    if(mysqli_stmt_num_rows($stmt)>0){
        echo "placa ya registrada";
        exit;
    }

    $query ="INSERT INTO vehiculos(id_usuario,placa,marca,modelo,color,tipo) VALUES(?,?,?,?,?,?)";
    $stmt =mysqli_prepare($conexion,$query);
    mysqli_stmt_bind_param($stmt,"isssss",$id_usuario,$placa,$marca,$modelo,$color,$tipo);

    if(mysqli_stmt_execute($stmt)){
        echo "vehiculo registrado";
    }else{
        echo "error en registro";
    }

    mysqli_close($conexion);

}

function accion_listar($conexion){

    $id_usuario =intval($_POST['id_usuario']);

    $result =array();
    $result['datos'] =array();

    $stmt =mysqli_prepare($conexion,"SELECT id_vehiculo,placa,marca,modelo,color,tipo FROM vehiculos WHERE id_usuario=? ORDER BY id_vehiculo DESC");
    mysqli_stmt_bind_param($stmt,"i",$id_usuario);
    mysqli_stmt_execute($stmt);
    $responce =mysqli_stmt_get_result($stmt);

    while($row =mysqli_fetch_array($responce))
    {
        $index['id_vehiculo'] =$row['0'];
        $index['placa'] =$row['1'];
        $index['marca'] =$row['2'];
        $index['modelo'] =$row['3'];
        $index['color'] =$row['4'];
        $index['tipo'] =$row['5'];

        array_push($result['datos'], $index);
    }
    $result["exito"]="1";
    echo json_encode($result);

    mysqli_close($conexion);

}

function accion_eliminar($conexion){

    $id_vehiculo =intval($_POST['id_vehiculo']);
    $id_usuario =intval($_POST['id_usuario']);

    $stmt =mysqli_prepare($conexion,"DELETE FROM vehiculos WHERE id_vehiculo=? AND id_usuario=?");
    mysqli_stmt_bind_param($stmt,"ii",$id_vehiculo,$id_usuario);
    mysqli_stmt_execute($stmt);

    if(mysqli_stmt_affected_rows($stmt)>0){
        echo "datos eliminados";
    }else{
        echo "error";
    }

    mysqli_close($conexion);

}

?>

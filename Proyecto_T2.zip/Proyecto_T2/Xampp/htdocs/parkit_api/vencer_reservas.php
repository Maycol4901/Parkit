<?php

// las reservas pendientes que no se confirman en 10 minutos se cancelan y el espacio queda libre
$limite ="fecha_creacion < (NOW() - INTERVAL 10 MINUTE)";

mysqli_query($conexion,"INSERT INTO notificaciones(id_usuario,titulo,mensaje,tipo)
                        SELECT id_usuario,'Reserva vencida','Su reserva no se confirmo a tiempo y fue cancelada','reserva'
                        FROM reservas WHERE estado='pendiente' AND ".$limite);
mysqli_query($conexion,"UPDATE espacios e INNER JOIN reservas r ON r.id_espacio=e.id_espacio
                        SET e.estado='disponible'
                        WHERE r.estado='pendiente' AND e.estado='reservado' AND r.".$limite);
mysqli_query($conexion,"UPDATE reservas SET estado='cancelada' WHERE estado='pendiente' AND ".$limite);

?>

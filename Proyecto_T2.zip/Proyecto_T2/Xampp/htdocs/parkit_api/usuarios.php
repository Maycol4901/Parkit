<?php

include 'conexion.php';

// la accion llega en la url (ej: usuarios.php?accion=login)
$accion =isset($_GET['accion']) ? $_GET['accion'] : '';

switch($accion){
    case 'login':
        accion_login($conexion);
        break;
    case 'insertar_conductor':
        accion_insertar_conductor($conexion);
        break;
    case 'insertar_encargado':
        accion_insertar_encargado($conexion);
        break;
    default:
        echo "accion no valida";
}

function accion_login($conexion){

    $correo =strtolower(trim($_POST['correo']));
    $contrasena =$_POST['contrasena'];

    $result =array();

    $query ="SELECT u.id_usuario,u.nombre,u.apellido,u.correo,u.contrasena,u.rol,e.id_estacionamiento,e.nombre AS nombre_estacionamiento
             FROM usuarios u
             LEFT JOIN estacionamientos e ON e.id_encargado=u.id_usuario
             WHERE u.correo=?";
    $stmt =mysqli_prepare($conexion,$query);
    mysqli_stmt_bind_param($stmt,"s",$correo);
    mysqli_stmt_execute($stmt);
    $row =mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    if($row && password_verify($contrasena,$row['contrasena'])){
        $index['id_usuario'] =$row['id_usuario'];
        $index['nombre'] =$row['nombre'];
        $index['apellido'] =$row['apellido'];
        $index['correo'] =$row['correo'];
        $index['rol'] =$row['rol'];
        $index['id_estacionamiento'] =$row['id_estacionamiento'] ? $row['id_estacionamiento'] : "0";
        $index['nombre_estacionamiento'] =$row['nombre_estacionamiento'] ? $row['nombre_estacionamiento'] : "";

        $result['usuario'] =$index;
        $result['exito'] ="1";
    }else{
        $result['exito'] ="0";
        $result['mensaje'] ="correo o contrasena incorrectos";
    }

    echo json_encode($result);

    mysqli_close($conexion);

}

function accion_insertar_conductor($conexion){

    $nombre =trim($_POST['nombre']);
    $apellido =trim($_POST['apellido']);
    $dni =trim($_POST['dni']);
    $telefono =trim($_POST['telefono']);
    $correo =strtolower(trim($_POST['correo']));
    $contrasena =$_POST['contrasena'];

    if($nombre=='' || $apellido=='' || !preg_match('/^[0-9]{8}$/',$dni) || !preg_match('/^9[0-9]{8}$/',$telefono)){
        echo "datos invalidos";
        exit;
    }
    if(!filter_var($correo,FILTER_VALIDATE_EMAIL)){
        echo "correo invalido";
        exit;
    }
    if(strlen($contrasena)<8 || !preg_match('/[A-Z]/',$contrasena) || !preg_match('/[0-9]/',$contrasena)){
        echo "contrasena insegura";
        exit;
    }

    // que el correo y el dni no esten registrados
    $stmt =mysqli_prepare($conexion,"SELECT id_usuario FROM usuarios WHERE correo=? OR dni=?");
    mysqli_stmt_bind_param($stmt,"ss",$correo,$dni);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);
    if(mysqli_stmt_num_rows($stmt)>0){
        echo "correo o dni ya registrado";
        exit;
    }

    $clave =password_hash($contrasena,PASSWORD_DEFAULT);
    $query ="INSERT INTO usuarios(nombre,apellido,dni,telefono,correo,contrasena,rol) VALUES(?,?,?,?,?,?,'conductor')";
    $stmt =mysqli_prepare($conexion,$query);
    mysqli_stmt_bind_param($stmt,"ssssss",$nombre,$apellido,$dni,$telefono,$correo,$clave);

    if(mysqli_stmt_execute($stmt)){
        echo "registro exitoso";
    }else{
        echo "error en registro";
    }

    mysqli_close($conexion);

}

function accion_insertar_encargado($conexion){

    $nombre =trim($_POST['nombre']);
    $apellido =trim($_POST['apellido']);
    $dni =trim($_POST['dni']);
    $telefono =trim($_POST['telefono']);
    $correo =strtolower(trim($_POST['correo']));
    $contrasena =$_POST['contrasena'];
    $codigo =strtoupper(trim($_POST['codigo']));

    if($nombre=='' || $apellido=='' || $codigo=='' || !preg_match('/^[0-9]{8}$/',$dni) || !preg_match('/^9[0-9]{8}$/',$telefono)){
        echo "datos invalidos";
        exit;
    }
    if(!filter_var($correo,FILTER_VALIDATE_EMAIL)){
        echo "correo invalido";
        exit;
    }
    if(strlen($contrasena)<8 || !preg_match('/[A-Z]/',$contrasena) || !preg_match('/[0-9]/',$contrasena)){
        echo "contrasena insegura";
        exit;
    }

    // revisamos el codigo de autorizacion
    $stmt =mysqli_prepare($conexion,"SELECT id_codigo,id_estacionamiento,usado,(fecha_vencimiento < NOW()) AS vencido FROM codigos_encargado WHERE codigo=?");
    mysqli_stmt_bind_param($stmt,"s",$codigo);
    mysqli_stmt_execute($stmt);
    $fila =mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    if(!$fila){
        echo "codigo invalido";
        exit;
    }
    if($fila['usado']==1){
        echo "codigo ya utilizado";
        exit;
    }
    if($fila['vencido']==1){
        echo "codigo vencido";
        exit;
    }

    // que el correo y el dni no esten registrados
    $stmt =mysqli_prepare($conexion,"SELECT id_usuario FROM usuarios WHERE correo=? OR dni=?");
    mysqli_stmt_bind_param($stmt,"ss",$correo,$dni);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);
    if(mysqli_stmt_num_rows($stmt)>0){
        echo "correo o dni ya registrado";
        exit;
    }

    // los tres pasos se guardan juntos o no se guarda ninguno
    mysqli_begin_transaction($conexion);

    $clave =password_hash($contrasena,PASSWORD_DEFAULT);
    $query ="INSERT INTO usuarios(nombre,apellido,dni,telefono,correo,contrasena,rol) VALUES(?,?,?,?,?,?,'encargado')";
    $stmt =mysqli_prepare($conexion,$query);
    mysqli_stmt_bind_param($stmt,"ssssss",$nombre,$apellido,$dni,$telefono,$correo,$clave);
    $paso1 =mysqli_stmt_execute($stmt);
    $id_usuario =mysqli_insert_id($conexion);

    $stmt =mysqli_prepare($conexion,"UPDATE estacionamientos SET id_encargado=? WHERE id_estacionamiento=?");
    mysqli_stmt_bind_param($stmt,"ii",$id_usuario,$fila['id_estacionamiento']);
    $paso2 =mysqli_stmt_execute($stmt);

    $stmt =mysqli_prepare($conexion,"UPDATE codigos_encargado SET usado=1, fecha_uso=NOW() WHERE id_codigo=? AND usado=0");
    mysqli_stmt_bind_param($stmt,"i",$fila['id_codigo']);
    $paso3 =mysqli_stmt_execute($stmt);
    $filas =mysqli_stmt_affected_rows($stmt);

    if($paso1 && $paso2 && $paso3 && $filas==1){
        mysqli_commit($conexion);
        echo "registro exitoso";
    }else{
        mysqli_rollback($conexion);
        echo "error en registro";
    }

    mysqli_close($conexion);

}

?>

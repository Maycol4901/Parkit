<?php

include 'conexion.php';
include 'vencer_reservas.php';

// la accion llega en la url (ej: estacionamientos.php?accion=listar)
$accion =isset($_GET['accion']) ? $_GET['accion'] : '';

switch($accion){
    case 'listar':
        accion_listar($conexion);
        break;
    case 'obtener':
        accion_obtener($conexion);
        break;
    case 'actualizar':
        accion_actualizar($conexion);
        break;
    default:
        echo "accion no valida";
}

function accion_listar($conexion){

    $busqueda =isset($_POST['busqueda']) ? trim($_POST['busqueda']) : '';
    $latitud =isset($_POST['latitud']) ? $_POST['latitud'] : '';
    $longitud =isset($_POST['longitud']) ? $_POST['longitud'] : '';

    // distancia maxima para considerar un estacionamiento "cercano"
    $radio_km =10;
    $texto ="%".$busqueda."%";

    $result =array();
    $result['datos'] =array();

    if(is_numeric($latitud) && is_numeric($longitud)){
        $lat =floatval($latitud);
        $lng =floatval($longitud);
        $query ="SELECT id_estacionamiento,nombre,direccion,distrito,latitud,longitud,tarifa_hora,
                 TIME_FORMAT(hora_apertura,'%H:%i'),TIME_FORMAT(hora_cierre,'%H:%i'),total_espacios,
                 (SELECT COUNT(*) FROM espacios s WHERE s.id_estacionamiento=estacionamientos.id_estacionamiento AND s.estado='disponible') AS disponibles,
                 (6371 * ACOS(LEAST(1, COS(RADIANS(?)) * COS(RADIANS(latitud)) * COS(RADIANS(longitud) - RADIANS(?)) + SIN(RADIANS(?)) * SIN(RADIANS(latitud))))) AS distancia
                 FROM estacionamientos
                 WHERE (nombre LIKE ? OR direccion LIKE ? OR distrito LIKE ?)
                 HAVING distancia <= ?
                 ORDER BY distancia";
        $stmt =mysqli_prepare($conexion,$query);
        mysqli_stmt_bind_param($stmt,"dddsssd",$lat,$lng,$lat,$texto,$texto,$texto,$radio_km);
    }else{
        $query ="SELECT id_estacionamiento,nombre,direccion,distrito,latitud,longitud,tarifa_hora,
                 TIME_FORMAT(hora_apertura,'%H:%i'),TIME_FORMAT(hora_cierre,'%H:%i'),total_espacios,
                 (SELECT COUNT(*) FROM espacios s WHERE s.id_estacionamiento=estacionamientos.id_estacionamiento AND s.estado='disponible') AS disponibles,'' AS distancia
                 FROM estacionamientos
                 WHERE (nombre LIKE ? OR direccion LIKE ? OR distrito LIKE ?)
                 ORDER BY nombre";
        $stmt =mysqli_prepare($conexion,$query);
        mysqli_stmt_bind_param($stmt,"sss",$texto,$texto,$texto);
    }

    mysqli_stmt_execute($stmt);
    $responce =mysqli_stmt_get_result($stmt);

    while($row =mysqli_fetch_array($responce))
    {
        $index['id_estacionamiento'] =$row['0'];
        $index['nombre'] =$row['1'];
        $index['direccion'] =$row['2'];
        $index['distrito'] =$row['3'];
        $index['latitud'] =$row['4'];
        $index['longitud'] =$row['5'];
        $index['tarifa_hora'] =$row['6'];
        $index['hora_apertura'] =$row['7'];
        $index['hora_cierre'] =$row['8'];
        $index['total_espacios'] =$row['9'];
        $index['disponibles'] =$row['10'];
        $index['distancia'] =is_numeric($row['11']) ? strval(round($row['11'],1)) : "";

        array_push($result['datos'], $index);
    }
    $result["exito"]="1";
    echo json_encode($result);

    mysqli_close($conexion);

}

function accion_obtener($conexion){

    $id =intval($_POST['id_estacionamiento']);

    $result =array();

    $query ="SELECT id_estacionamiento,nombre,direccion,distrito,latitud,longitud,tarifa_hora,
             TIME_FORMAT(hora_apertura,'%H:%i'),TIME_FORMAT(hora_cierre,'%H:%i'),total_espacios,
             (SELECT COUNT(*) FROM espacios s WHERE s.id_estacionamiento=estacionamientos.id_estacionamiento AND s.estado='disponible')
             FROM estacionamientos WHERE id_estacionamiento=?";
    $stmt =mysqli_prepare($conexion,$query);
    mysqli_stmt_bind_param($stmt,"i",$id);
    mysqli_stmt_execute($stmt);
    $row =mysqli_fetch_array(mysqli_stmt_get_result($stmt));

    if($row){
        $index['id_estacionamiento'] =$row['0'];
        $index['nombre'] =$row['1'];
        $index['direccion'] =$row['2'];
        $index['distrito'] =$row['3'];
        $index['latitud'] =$row['4'];
        $index['longitud'] =$row['5'];
        $index['tarifa_hora'] =$row['6'];
        $index['hora_apertura'] =$row['7'];
        $index['hora_cierre'] =$row['8'];
        $index['total_espacios'] =$row['9'];
        $index['disponibles'] =$row['10'];

        $result['estacionamiento'] =$index;
        $result['exito'] ="1";
    }else{
        $result['exito'] ="0";
        $result['mensaje'] ="estacionamiento no encontrado";
    }

    echo json_encode($result);

    mysqli_close($conexion);

}

function accion_actualizar($conexion){

    $id_usuario =intval($_POST['id_usuario']);
    $nombre =trim($_POST['nombre']);
    $direccion =trim($_POST['direccion']);
    $tarifa =$_POST['tarifa_hora'];
    $apertura =trim($_POST['hora_apertura']);
    $cierre =trim($_POST['hora_cierre']);
    $total =intval($_POST['total_espacios']);

    $formato_hora ='/^([01][0-9]|2[0-3]):[0-5][0-9]$/';

    if($nombre=='' || $direccion=='' || !is_numeric($tarifa) || $tarifa<0 || $tarifa>999){
        echo "datos invalidos";
        exit;
    }
    if(!preg_match($formato_hora,$apertura) || !preg_match($formato_hora,$cierre)){
        echo "horario invalido";
        exit;
    }
    if($total<1 || $total>200){
        echo "la cantidad de espacios debe estar entre 1 y 200";
        exit;
    }

    // solo el encargado de ese estacionamiento lo puede editar
    $stmt =mysqli_prepare($conexion,"SELECT id_estacionamiento FROM estacionamientos WHERE id_encargado=?");
    mysqli_stmt_bind_param($stmt,"i",$id_usuario);
    mysqli_stmt_execute($stmt);
    $fila =mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    if(!$fila){
        echo "usuario no autorizado";
        exit;
    }
    $id_est =$fila['id_estacionamiento'];

    // los espacios que tiene ahora
    $stmt =mysqli_prepare($conexion,"SELECT id_espacio,estado FROM espacios WHERE id_estacionamiento=? ORDER BY id_espacio");
    mysqli_stmt_bind_param($stmt,"i",$id_est);
    mysqli_stmt_execute($stmt);
    $res =mysqli_stmt_get_result($stmt);
    $espacios =array();
    while($e =mysqli_fetch_assoc($res)){
        array_push($espacios,$e);
    }
    $actual =count($espacios);

    // para bajar la cantidad solo se pueden quitar espacios disponibles
    if($total<$actual){
        for($i=$total;$i<$actual;$i++){
            if($espacios[$i]['estado']!='disponible'){
                echo "no se pueden quitar espacios ocupados o reservados";
                exit;
            }
        }
    }

    mysqli_begin_transaction($conexion);

    $stmt =mysqli_prepare($conexion,"UPDATE estacionamientos SET nombre=?,direccion=?,tarifa_hora=?,hora_apertura=?,hora_cierre=?,total_espacios=? WHERE id_estacionamiento=?");
    mysqli_stmt_bind_param($stmt,"ssdssii",$nombre,$direccion,$tarifa,$apertura,$cierre,$total,$id_est);
    $ok =mysqli_stmt_execute($stmt);

    if($total>$actual){
        $stmt =mysqli_prepare($conexion,"INSERT INTO espacios(id_estacionamiento,codigo) VALUES(?,?)");
        for($i=$actual+1;$i<=$total;$i++){
            $codigo =sprintf("A-%02d",$i);
            mysqli_stmt_bind_param($stmt,"is",$id_est,$codigo);
            $ok =$ok && mysqli_stmt_execute($stmt);
        }
    }

    if($total<$actual){
        $stmt =mysqli_prepare($conexion,"DELETE FROM espacios WHERE id_espacio=?");
        for($i=$total;$i<$actual;$i++){
            $id_espacio =$espacios[$i]['id_espacio'];
            mysqli_stmt_bind_param($stmt,"i",$id_espacio);
            $ok =$ok && mysqli_stmt_execute($stmt);
        }
    }

    if($ok){
        mysqli_commit($conexion);
        echo "datos actualizados";
    }else{
        mysqli_rollback($conexion);
        echo "error en actualizacion, no se pueden quitar espacios que ya tienen reservas";
    }

    mysqli_close($conexion);

}

?>

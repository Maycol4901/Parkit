<?php
mysqli_report(MYSQLI_REPORT_OFF);
$conexion = mysqli_connect('localhost','root','','base_aplicativo',3307);
if(!$conexion){
    echo "error en conexion";
    exit;
}
mysqli_set_charset($conexion,'utf8mb4');

<?php

include 'conexion.php';

// la accion llega en la url (ej: movimientos.php?accion=entrada)
$accion =isset($_GET['accion']) ? $_GET['accion'] : '';

switch($accion){
    case 'entrada':
        accion_entrada($conexion);
        break;
    case 'salida':
        accion_salida($conexion);
        break;
    case 'liberar':
        accion_liberar($conexion);
        break;
    default:
        echo "accion no valida";
}

function accion_entrada($conexion){

    date_default_timezone_set('America/Lima');

    $id_usuario =intval($_POST['id_usuario']);
    $id_reserva =intval($_POST['id_reserva']);

    // la reserva debe ser de un espacio del estacionamiento de este encargado
    $query ="SELECT r.id_vehiculo,r.id_espacio,r.estado FROM reservas r
             INNER JOIN espacios e ON e.id_espacio=r.id_espacio
             INNER JOIN estacionamientos p ON p.id_estacionamiento=e.id_estacionamiento
             WHERE r.id_reserva=? AND p.id_encargado=?";
    $stmt =mysqli_prepare($conexion,$query);
    mysqli_stmt_bind_param($stmt,"ii",$id_reserva,$id_usuario);
    mysqli_stmt_execute($stmt);
    $row =mysqli_fetch_array(mysqli_stmt_get_result($stmt));
    if(!$row){
        echo "reserva no encontrada";
        exit;
    }
    if($row['2']!='confirmada'){
        echo "solo se registra la entrada de reservas confirmadas";
        exit;
    }
    $id_vehiculo =$row['0'];
    $id_espacio =$row['1'];
    $ahora =date('Y-m-d H:i:s');

    mysqli_begin_transaction($conexion);

    $stmt =mysqli_prepare($conexion,"UPDATE reservas SET estado='en_curso' WHERE id_reserva=? AND estado='confirmada'");
    mysqli_stmt_bind_param($stmt,"i",$id_reserva);
    mysqli_stmt_execute($stmt);
    if(mysqli_stmt_affected_rows($stmt)!=1){
        mysqli_rollback($conexion);
        echo "la reserva ya no esta confirmada";
        exit;
    }

    $stmt =mysqli_prepare($conexion,"UPDATE espacios SET estado='ocupado' WHERE id_espacio=?");
    mysqli_stmt_bind_param($stmt,"i",$id_espacio);
    mysqli_stmt_execute($stmt);

    $stmt =mysqli_prepare($conexion,"INSERT INTO movimientos(id_espacio,id_vehiculo,id_reserva,hora_ingreso) VALUES(?,?,?,?)");
    mysqli_stmt_bind_param($stmt,"iiis",$id_espacio,$id_vehiculo,$id_reserva,$ahora);
    mysqli_stmt_execute($stmt);

    $query ="INSERT INTO notificaciones(id_usuario,titulo,mensaje,tipo)
             SELECT r.id_usuario,'Ingreso registrado',
                    CONCAT('Su vehiculo ingreso al espacio ',e.codigo,' en ',p.nombre),'movimiento'
             FROM reservas r
             INNER JOIN espacios e ON e.id_espacio=r.id_espacio
             INNER JOIN estacionamientos p ON p.id_estacionamiento=e.id_estacionamiento
             WHERE r.id_reserva=?";
    $stmt =mysqli_prepare($conexion,$query);
    mysqli_stmt_bind_param($stmt,"i",$id_reserva);
    mysqli_stmt_execute($stmt);

    mysqli_commit($conexion);
    echo "entrada registrada";

    mysqli_close($conexion);

}

function accion_salida($conexion){

    date_default_timezone_set('America/Lima');

    $id_usuario =intval($_POST['id_usuario']);
    $id_reserva =intval($_POST['id_reserva']);

    $query ="SELECT r.id_espacio,r.estado FROM reservas r
             INNER JOIN espacios e ON e.id_espacio=r.id_espacio
             INNER JOIN estacionamientos p ON p.id_estacionamiento=e.id_estacionamiento
             WHERE r.id_reserva=? AND p.id_encargado=?";
    $stmt =mysqli_prepare($conexion,$query);
    mysqli_stmt_bind_param($stmt,"ii",$id_reserva,$id_usuario);
    mysqli_stmt_execute($stmt);
    $row =mysqli_fetch_array(mysqli_stmt_get_result($stmt));
    if(!$row){
        echo "reserva no encontrada";
        exit;
    }
    if($row['1']!='en_curso'){
        echo "el vehiculo no esta dentro del estacionamiento";
        exit;
    }
    $id_espacio =$row['0'];
    $ahora =date('Y-m-d H:i:s');

    mysqli_begin_transaction($conexion);

    $stmt =mysqli_prepare($conexion,"UPDATE reservas SET estado='finalizada' WHERE id_reserva=? AND estado='en_curso'");
    mysqli_stmt_bind_param($stmt,"i",$id_reserva);
    mysqli_stmt_execute($stmt);
    if(mysqli_stmt_affected_rows($stmt)!=1){
        mysqli_rollback($conexion);
        echo "el vehiculo no esta dentro del estacionamiento";
        exit;
    }

    $stmt =mysqli_prepare($conexion,"UPDATE espacios SET estado='disponible' WHERE id_espacio=?");
    mysqli_stmt_bind_param($stmt,"i",$id_espacio);
    mysqli_stmt_execute($stmt);

    $stmt =mysqli_prepare($conexion,"UPDATE movimientos SET hora_salida=? WHERE id_reserva=? AND hora_salida IS NULL");
    mysqli_stmt_bind_param($stmt,"si",$ahora,$id_reserva);
    mysqli_stmt_execute($stmt);

    $query ="INSERT INTO notificaciones(id_usuario,titulo,mensaje,tipo)
             SELECT r.id_usuario,'Salida registrada',
                    CONCAT('Su vehiculo salio del espacio ',e.codigo,' en ',p.nombre,'. Gracias por usar Parkit'),'movimiento'
             FROM reservas r
             INNER JOIN espacios e ON e.id_espacio=r.id_espacio
             INNER JOIN estacionamientos p ON p.id_estacionamiento=e.id_estacionamiento
             WHERE r.id_reserva=?";
    $stmt =mysqli_prepare($conexion,$query);
    mysqli_stmt_bind_param($stmt,"i",$id_reserva);
    mysqli_stmt_execute($stmt);

    mysqli_commit($conexion);
    echo "salida registrada";

    mysqli_close($conexion);

}

function accion_liberar($conexion){

    $id_usuario =intval($_POST['id_usuario']);
    $id_reserva =intval($_POST['id_reserva']);

    $query ="SELECT r.id_espacio,r.estado FROM reservas r
             INNER JOIN espacios e ON e.id_espacio=r.id_espacio
             INNER JOIN estacionamientos p ON p.id_estacionamiento=e.id_estacionamiento
             WHERE r.id_reserva=? AND p.id_encargado=?";
    $stmt =mysqli_prepare($conexion,$query);
    mysqli_stmt_bind_param($stmt,"ii",$id_reserva,$id_usuario);
    mysqli_stmt_execute($stmt);
    $row =mysqli_fetch_array(mysqli_stmt_get_result($stmt));
    if(!$row){
        echo "reserva no encontrada";
        exit;
    }
    // si el vehiculo ya ingreso se debe registrar su salida, no liberar
    if($row['1']!='pendiente' && $row['1']!='confirmada'){
        echo "la reserva no se puede liberar";
        exit;
    }
    $id_espacio =$row['0'];

    mysqli_begin_transaction($conexion);

    $stmt =mysqli_prepare($conexion,"UPDATE reservas SET estado='cancelada' WHERE id_reserva=? AND estado IN ('pendiente','confirmada')");
    mysqli_stmt_bind_param($stmt,"i",$id_reserva);
    mysqli_stmt_execute($stmt);
    if(mysqli_stmt_affected_rows($stmt)!=1){
        mysqli_rollback($conexion);
        echo "la reserva no se puede liberar";
        exit;
    }

    $stmt =mysqli_prepare($conexion,"UPDATE espacios SET estado='disponible' WHERE id_espacio=?");
    mysqli_stmt_bind_param($stmt,"i",$id_espacio);
    mysqli_stmt_execute($stmt);

    $query ="INSERT INTO notificaciones(id_usuario,titulo,mensaje,tipo)
             SELECT r.id_usuario,'Reserva liberada',
                    CONCAT('El encargado libero su reserva del espacio ',e.codigo,' en ',p.nombre),'reserva'
             FROM reservas r
             INNER JOIN espacios e ON e.id_espacio=r.id_espacio
             INNER JOIN estacionamientos p ON p.id_estacionamiento=e.id_estacionamiento
             WHERE r.id_reserva=?";
    $stmt =mysqli_prepare($conexion,$query);
    mysqli_stmt_bind_param($stmt,"i",$id_reserva);
    mysqli_stmt_execute($stmt);

    mysqli_commit($conexion);
    echo "espacio liberado";

    mysqli_close($conexion);

}

?>

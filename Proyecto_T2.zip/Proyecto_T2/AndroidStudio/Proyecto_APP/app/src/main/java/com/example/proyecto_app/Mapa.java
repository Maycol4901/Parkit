package com.example.proyecto_app;

import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Marker;

import java.util.HashMap;
import java.util.Map;

public class Mapa extends AppCompatActivity {

    MapView mapa;
    TextView t1;
    Button b1,b2,b3;
    Marker marcadorUsuario;
    Estacionamiento seleccionado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        // configuracion de osmdroid, va antes del setContentView
        Ubicacion.iniciarMapa(this);

        setContentView(R.layout.activity_mapa);

        mapa = (MapView) findViewById(R.id.mapa);
        t1 = (TextView) findViewById(R.id.info);
        b1 = (Button) findViewById(R.id.bt1);
        b2 = (Button) findViewById(R.id.bt2);
        b3 = (Button) findViewById(R.id.bt3);

        // el mapa siempre arranca en Los Olivos
        Ubicacion.prepararMapa(this, mapa, 14.0);

        b1.setVisibility(View.GONE);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), DetalleEstacionamiento.class);
                i.putExtra("id", seleccionado.getId());
                startActivity(i);
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                miUbicacion();
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        ListarDatos();
    }

    @Override
    protected void onResume() {
        super.onResume();
        mapa.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        mapa.onPause();
    }

    // marca donde esta el celular (o Lima si no se pudo saber)
    Ubicacion.Resultado resultado = new Ubicacion.Resultado() {
        @Override
        public void listo(double latitud, double longitud, boolean real) {
            GeoPoint punto = new GeoPoint(latitud, longitud);
            if (marcadorUsuario == null){
                marcadorUsuario = new Marker(mapa);
                marcadorUsuario.setIcon(getDrawable(android.R.drawable.ic_menu_mylocation));
                marcadorUsuario.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER);
                mapa.getOverlays().add(marcadorUsuario);
            }
            if (real){
                marcadorUsuario.setTitle("Usted esta aqui");
            }else {
                marcadorUsuario.setTitle("Lima (ubicacion de referencia)");
            }
            marcadorUsuario.setPosition(punto);
            mapa.getController().setZoom(15.0);
            mapa.getController().animateTo(punto);
            mapa.invalidate();
        }
    };

    public void miUbicacion()
    {
        if (Ubicacion.tienePermiso(this)){
            Ubicacion.obtener(this, resultado);
        }else {
            Ubicacion.pedirPermiso(this);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == Ubicacion.PERMISO) {
            if (Ubicacion.tienePermiso(this)) {
                Ubicacion.obtener(this, resultado);
            } else {
                Ubicacion.usarLima(this, "sin permiso de ubicacion, se usa Lima como referencia", resultado);
            }
        }
    }

    // un marcador por cada estacionamiento
    public void ListarDatos(){

        StringRequest request =new StringRequest(Request.Method.POST, Config.URL_LISTAR_ESTACIONAMIENTOS,
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        try {

                            JSONObject jsonObject =new JSONObject(response);
                            String exito=jsonObject.getString("exito");
                            JSONArray jsonArray =jsonObject.getJSONArray("datos");
                            if (exito.equals("1")){
                                for (int i=0;i<jsonArray.length();i++){
                                    Estacionamiento e = Estacionamiento.desdeJson(jsonArray.getJSONObject(i));

                                    Marker marcador = new Marker(mapa);
                                    marcador.setPosition(new GeoPoint(Double.parseDouble(e.getLatitud()), Double.parseDouble(e.getLongitud())));
                                    marcador.setTitle(e.getNombre());
                                    marcador.setSnippet(e.getDireccion());
                                    marcador.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
                                    marcador.setOnMarkerClickListener(new Marker.OnMarkerClickListener() {
                                        @Override
                                        public boolean onMarkerClick(Marker marker, MapView mapView) {
                                            seleccionar(e, marker);
                                            return true;
                                        }
                                    });
                                    mapa.getOverlays().add(marcador);
                                }
                                mapa.invalidate();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Mapa.this,"no se pudo conectar con el servidor",Toast.LENGTH_SHORT).show();
            }
        }
        ){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String>params=new HashMap<>();

                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(Mapa.this);
        requestQueue.add(request);

    }

    public void seleccionar(Estacionamiento e, Marker marcador)
    {
        seleccionado = e;
        t1.setText(e.getNombre() + "\n" + e.getDireccion() + ", " + e.getDistrito() + "\nS/ " + e.getTarifa() + " por hora  -  " + e.getApertura() + " a " + e.getCierre());
        b1.setVisibility(View.VISIBLE);
        marcador.showInfoWindow();
        mapa.getController().animateTo(marcador.getPosition());
    }
}

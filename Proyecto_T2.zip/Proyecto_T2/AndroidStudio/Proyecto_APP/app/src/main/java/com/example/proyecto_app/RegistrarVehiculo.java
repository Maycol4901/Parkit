package com.example.proyecto_app;

import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import android.app.ProgressDialog;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class RegistrarVehiculo extends AppCompatActivity {

    EditText ed1,ed2,ed3,ed4;
    Spinner sp1;
    Button b1,b2;
    SesionManager sesion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_registrar_vehiculo);

        sesion = new SesionManager(this);

        ed1 = (EditText) findViewById(R.id.placa);
        ed2 = (EditText) findViewById(R.id.marca);
        ed3 = (EditText) findViewById(R.id.modelo);
        ed4 = (EditText) findViewById(R.id.color);
        sp1 = (Spinner) findViewById(R.id.tipo);
        b1 = (Button) findViewById(R.id.bt1);
        b2 = (Button) findViewById(R.id.bt2);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                insert();
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    public void insert()
    {
        String placa = ed1.getText().toString().trim().toUpperCase().replace("-","");
        String marca = ed2.getText().toString().trim();
        String modelo = ed3.getText().toString().trim();
        String color = ed4.getText().toString().trim();
        String tipo = sp1.getSelectedItem().toString().toLowerCase();
        String id_usuario = sesion.getUsuario().getId();

        ProgressDialog progressDialog =new ProgressDialog(this);
        progressDialog.setMessage("Guardando");

        if (placa.length() != 6){
            Toast.makeText(this,"ingrese una placa de 6 caracteres, ejemplo ABC-123",Toast.LENGTH_SHORT).show();
        }else if (marca.isEmpty()){
            Toast.makeText(this,"ingrese marca",Toast.LENGTH_SHORT).show();
        }else if (modelo.isEmpty()){
            Toast.makeText(this,"ingrese modelo",Toast.LENGTH_SHORT).show();
        }else if (color.isEmpty()){
            Toast.makeText(this,"ingrese color",Toast.LENGTH_SHORT).show();
        }else {
            progressDialog.show();
            StringRequest request =new StringRequest(Request.Method.POST, Config.URL_REGISTRAR_VEHICULO,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            progressDialog.dismiss();
                            if (response.trim().equalsIgnoreCase("vehiculo registrado")) {
                                Toast.makeText(RegistrarVehiculo.this, "registrado correctamente", Toast.LENGTH_SHORT).show();
                                finish();
                            } else {
                                Toast.makeText(RegistrarVehiculo.this, response.trim(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(RegistrarVehiculo.this,"no se pudo conectar con el servidor",Toast.LENGTH_SHORT).show();
                    progressDialog.dismiss();
                }
            }
            ){

                @Override
                protected Map<String, String> getParams() throws AuthFailureError {

                    Map<String,String>params=new HashMap<>();
                    params.put("id_usuario",id_usuario);
                    params.put("placa",placa);
                    params.put("marca",marca);
                    params.put("modelo",modelo);
                    params.put("color",color);
                    params.put("tipo",tipo);

                    return params;
                }
            };
            RequestQueue requestQueue = Volley.newRequestQueue(RegistrarVehiculo.this);
            requestQueue.add(request);
        }
    }

}

package com.example.proyecto_app;

import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ConfirmarReserva extends AppCompatActivity {

    TextView t1,t2,t3,t4,t5,t6,t7,t8,t9;
    Spinner s1;
    Button b1,b2,b3;
    ArrayList<String> metodos_ = new ArrayList<String>();
    ArrayList<String> idsMetodos = new ArrayList<String>();
    ArrayAdapter arrayAdapter;
    SesionManager sesion;
    String idReserva;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_confirmar_reserva);

        sesion = new SesionManager(this);

        t1 = (TextView) findViewById(R.id.nombre);
        t2 = (TextView) findViewById(R.id.espacio);
        t3 = (TextView) findViewById(R.id.vehiculo);
        t4 = (TextView) findViewById(R.id.fecha);
        t5 = (TextView) findViewById(R.id.horario);
        t6 = (TextView) findViewById(R.id.monto);
        t7 = (TextView) findViewById(R.id.estado);
        t8 = (TextView) findViewById(R.id.etiqueta_pago);
        t9 = (TextView) findViewById(R.id.nota);
        s1 = (Spinner) findViewById(R.id.metodo);
        b1 = (Button) findViewById(R.id.bt1);
        b2 = (Button) findViewById(R.id.bt2);
        b3 = (Button) findViewById(R.id.bt3);

        idReserva = getIntent().getStringExtra("id_reserva");

        arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, metodos_);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s1.setAdapter(arrayAdapter);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Confirmar();
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                preguntarCancelar();
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        ListarMetodos();
        Cargar();
    }

    public void ListarMetodos(){

        StringRequest request =new StringRequest(Request.Method.POST, Config.URL_LISTAR_METODOS_PAGO,
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        metodos_.clear();
                        idsMetodos.clear();
                        try {

                            JSONObject jsonObject =new JSONObject(response);
                            String exito=jsonObject.getString("exito");
                            JSONArray jsonArray =jsonObject.getJSONArray("datos");
                            if (exito.equals("1")){
                                for (int i=0;i<jsonArray.length();i++){
                                    JSONObject object=jsonArray.getJSONObject(i);
                                    idsMetodos.add(object.getString("id_metodo"));
                                    metodos_.add(object.getString("nombre"));
                                }
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        arrayAdapter.notifyDataSetChanged();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(ConfirmarReserva.this,"no se pudo conectar con el servidor",Toast.LENGTH_SHORT).show();
            }
        }
        ){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String>params=new HashMap<>();

                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(ConfirmarReserva.this);
        requestQueue.add(request);

    }

    // llena los datos y esconde los botones que ya no sirven segun el estado
    public void Cargar(){
        StringRequest request =new StringRequest(Request.Method.POST, Config.URL_OBTENER_RESERVA,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject json = new JSONObject(response);
                            if (json.getString("exito").equals("1")){
                                Reserva r = Reserva.desdeJson(json.getJSONObject("reserva"));
                                t1.setText(r.getEstacionamiento());
                                t2.setText("Espacio: " + r.getEspacio());
                                t3.setText("Vehículo: " + r.getPlaca());
                                t4.setText("Fecha: " + r.getFecha());
                                t5.setText("Horario: " + r.getInicio() + " a " + r.getFin());
                                t6.setText("Monto: S/ " + r.getMonto());
                                t7.setText("Estado: " + r.getEstado());

                                if (r.getEstado().equals("pendiente")){
                                    t9.setText("Confirme el pago antes de 10 minutos o la reserva se cancelará sola.");
                                }else {
                                    // si ya no esta pendiente no hay nada que pagar
                                    s1.setVisibility(View.GONE);
                                    t8.setVisibility(View.GONE);
                                    b1.setVisibility(View.GONE);
                                    t9.setText("Método de pago: " + (r.getMetodo().isEmpty() ? "-" : r.getMetodo()));
                                }
                                if (!r.getEstado().equals("pendiente") && !r.getEstado().equals("confirmada")){
                                    b2.setVisibility(View.GONE);
                                }
                            }else {
                                Toast.makeText(ConfirmarReserva.this, json.getString("mensaje"), Toast.LENGTH_SHORT).show();
                            }
                        } catch (Exception e) {
                            Toast.makeText(ConfirmarReserva.this, "error en la respuesta del servidor", Toast.LENGTH_SHORT).show();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(ConfirmarReserva.this,"no se pudo conectar con el servidor",Toast.LENGTH_SHORT).show();
            }
        }
        ){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String>params=new HashMap<>();
                params.put("id_usuario",sesion.getUsuario().getId());
                params.put("id_reserva",idReserva);

                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(ConfirmarReserva.this);
        requestQueue.add(request);
    }

    public void Confirmar()
    {
        if (idsMetodos.isEmpty()){
            Toast.makeText(this,"no hay metodos de pago disponibles",Toast.LENGTH_SHORT).show();
            return;
        }

        String idMetodo = idsMetodos.get(s1.getSelectedItemPosition());
        String nombreMetodo = metodos_.get(s1.getSelectedItemPosition());

        ProgressDialog progressDialog =new ProgressDialog(this);
        progressDialog.setMessage("Procesando pago");
        progressDialog.show();

        StringRequest request =new StringRequest(Request.Method.POST, Config.URL_CONFIRMAR_RESERVA,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();
                        if (response.equalsIgnoreCase("reserva confirmada")) {
                            Toast.makeText(ConfirmarReserva.this, "reserva confirmada, pago con " + nombreMetodo, Toast.LENGTH_LONG).show();
                            finish();
                        } else {
                            Toast.makeText(ConfirmarReserva.this, response, Toast.LENGTH_LONG).show();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(ConfirmarReserva.this,"no se pudo conectar con el servidor",Toast.LENGTH_SHORT).show();

            }
        }
        ){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String>params=new HashMap<>();
                params.put("id_usuario",sesion.getUsuario().getId());
                params.put("id_reserva",idReserva);
                params.put("id_metodo",idMetodo);

                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(ConfirmarReserva.this);
        requestQueue.add(request);
    }

    public void preguntarCancelar(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Cancelar reserva");
        builder.setMessage("Desea cancelar esta reserva? El espacio quedara libre.");
        builder.setPositiveButton("Cancelar reserva", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Cancelar();
            }
        });
        builder.setNegativeButton("No", null);
        builder.show();
    }

    public void Cancelar()
    {
        StringRequest request =new StringRequest(Request.Method.POST, Config.URL_CANCELAR_RESERVA,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        if (response.equalsIgnoreCase("reserva cancelada")) {
                            Toast.makeText(ConfirmarReserva.this, "reserva cancelada", Toast.LENGTH_SHORT).show();
                            finish();
                        } else {
                            Toast.makeText(ConfirmarReserva.this, response, Toast.LENGTH_LONG).show();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(ConfirmarReserva.this,"no se pudo conectar con el servidor",Toast.LENGTH_SHORT).show();

            }
        }
        ){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String>params=new HashMap<>();
                params.put("id_usuario",sesion.getUsuario().getId());
                params.put("id_reserva",idReserva);

                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(ConfirmarReserva.this);
        requestQueue.add(request);
    }
}

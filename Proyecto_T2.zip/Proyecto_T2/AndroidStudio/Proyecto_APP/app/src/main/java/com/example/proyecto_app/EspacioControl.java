package com.example.proyecto_app;

import org.json.JSONException;
import org.json.JSONObject;

public class EspacioControl {
    String id;
    String codigo;
    String estado;
    String idReserva;
    String placa;
    String conductor;
    String inicio;
    String fin;
    String estadoReserva;
    String monto;
    String ingreso;

    public EspacioControl(String id, String codigo, String estado, String idReserva, String placa, String conductor, String inicio, String fin, String estadoReserva, String monto, String ingreso) {
        this.id = id;
        this.codigo = codigo;
        this.estado = estado;
        this.idReserva = idReserva;
        this.placa = placa;
        this.conductor = conductor;
        this.inicio = inicio;
        this.fin = fin;
        this.estadoReserva = estadoReserva;
        this.monto = monto;
        this.ingreso = ingreso;
    }

    public EspacioControl() {
    }

    // convierte el json del php en un objeto
    public static EspacioControl desdeJson(JSONObject o) throws JSONException {
        return new EspacioControl(
                o.getString("id_espacio"),
                o.getString("codigo"),
                o.getString("estado"),
                o.getString("id_reserva"),
                o.getString("placa"),
                o.getString("conductor"),
                o.getString("hora_inicio"),
                o.getString("hora_fin"),
                o.getString("estado_reserva"),
                o.getString("monto"),
                o.getString("ingreso"));
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getIdReserva() {
        return idReserva;
    }

    public void setIdReserva(String idReserva) {
        this.idReserva = idReserva;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getConductor() {
        return conductor;
    }

    public void setConductor(String conductor) {
        this.conductor = conductor;
    }

    public String getInicio() {
        return inicio;
    }

    public void setInicio(String inicio) {
        this.inicio = inicio;
    }

    public String getFin() {
        return fin;
    }

    public void setFin(String fin) {
        this.fin = fin;
    }

    public String getEstadoReserva() {
        return estadoReserva;
    }

    public void setEstadoReserva(String estadoReserva) {
        this.estadoReserva = estadoReserva;
    }

    public String getMonto() {
        return monto;
    }

    public void setMonto(String monto) {
        this.monto = monto;
    }

    public String getIngreso() {
        return ingreso;
    }

    public void setIngreso(String ingreso) {
        this.ingreso = ingreso;
    }
}

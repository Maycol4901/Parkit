package com.example.proyecto_app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import org.osmdroid.config.Configuration;
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase;
import org.osmdroid.util.MapTileIndex;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;

import java.io.File;
import java.util.function.Consumer;

public class Ubicacion {

    public static final int PERMISO = 100;

    // punto de referencia por defecto: Los Olivos, Lima
    public static final double LIMA_LATITUD = -11.9900;
    public static final double LIMA_LONGITUD = -77.0700;

    // mas de 60 km de ese punto = estamos fuera de Lima
    public static final float RADIO_LIMA = 60000;

    // real = true si es la ubicacion del celular, false si se uso Lima
    public interface Resultado {
        void listo(double latitud, double longitud, boolean real);
    }

    public static boolean tienePermiso(Activity a) {
        boolean fina = ContextCompat.checkSelfPermission(a, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        boolean aproximada = ContextCompat.checkSelfPermission(a, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        return fina || aproximada;
    }

    public static void pedirPermiso(Activity a) {
        ActivityCompat.requestPermissions(a, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, PERMISO);
    }

    // avisa con un Toast y sigue usando Lima
    public static void usarLima(Activity a, String mensaje, Resultado resultado) {
        Toast.makeText(a, mensaje, Toast.LENGTH_LONG).show();
        resultado.listo(LIMA_LATITUD, LIMA_LONGITUD, false);
    }

    @SuppressLint("MissingPermission")
    public static void obtener(Activity a, Resultado resultado) {
        LocationManager lm = (LocationManager) a.getSystemService(Context.LOCATION_SERVICE);

        boolean fina = ContextCompat.checkSelfPermission(a, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        String proveedor = null;
        if (fina && lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            proveedor = LocationManager.GPS_PROVIDER;
        } else if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
            proveedor = LocationManager.NETWORK_PROVIDER;
        }

        if (proveedor == null) {
            usarLima(a, "la ubicacion del celular esta desactivada, se usa Lima como referencia", resultado);
            return;
        }

        Toast.makeText(a, "buscando su ubicacion", Toast.LENGTH_SHORT).show();
        lm.getCurrentLocation(proveedor, null, a.getMainExecutor(), new Consumer<Location>() {
            @Override
            public void accept(Location location) {
                if (location == null) {
                    usarLima(a, "no se pudo obtener su ubicacion, se usa Lima como referencia", resultado);
                    return;
                }

                float[] distancia = new float[1];
                Location.distanceBetween(location.getLatitude(), location.getLongitude(), LIMA_LATITUD, LIMA_LONGITUD, distancia);

                if (distancia[0] > RADIO_LIMA) {
                    usarLima(a, "su ubicacion esta fuera de Lima, se usa Lima como referencia", resultado);
                } else {
                    resultado.listo(location.getLatitude(), location.getLongitude(), true);
                }
            }
        });
    }

    // ---- mapa (osmdroid) ----

    // nombre propio de la app para identificarnos cuando el mapa descarga las imagenes
    public static final String USER_AGENT = "Parkit/1.0 (proyecto academico, Lima)";

    // se llama antes del setContentView de las pantallas con mapa
    public static void iniciarMapa(Context c) {
        Configuration.getInstance().load(c.getApplicationContext(), c.getSharedPreferences("osmdroid", Context.MODE_PRIVATE));
        Configuration.getInstance().setUserAgentValue(USER_AGENT);
        // algunos servidores de mapas piden saber de donde viene la peticion
        Configuration.getInstance().getAdditionalHttpRequestProperties().put("Referer", "https://parkit.app/");
        File carpeta = new File(c.getCacheDir(), "osmdroid");
        Configuration.getInstance().setOsmdroidBasePath(carpeta);
        Configuration.getInstance().setOsmdroidTileCache(new File(carpeta, "tiles"));
    }

    // deja el mapa listo y centrado en Los Olivos
    public static void prepararMapa(Context c, MapView mapa, double zoom) {
        // calles de Esri (gratis y sin clave). Pide los mosaicos como zoom/y/x,
        // por eso armamos la direccion a mano
        mapa.setTileSource(new OnlineTileSourceBase("EsriCalles", 0, 19, 256, "",
                new String[]{"https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/"}) {
            @Override
            public String getTileURLString(long pMapTileIndex) {
                return getBaseUrl() + MapTileIndex.getZoom(pMapTileIndex) + "/"
                        + MapTileIndex.getY(pMapTileIndex) + "/" + MapTileIndex.getX(pMapTileIndex);
            }
        });
        mapa.setUseDataConnection(true);
        mapa.setMultiTouchControls(true);
        mapa.setTilesScaledToDpi(true);
        mapa.getController().setZoom(zoom);
        mapa.getController().setCenter(new GeoPoint(LIMA_LATITUD, LIMA_LONGITUD));

        if (!hayInternet(c)) {
            Toast.makeText(c, "sin internet: el mapa no puede descargar las imagenes", Toast.LENGTH_LONG).show();
        }
    }

    public static boolean hayInternet(Context c) {
        ConnectivityManager cm = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
        Network red = cm.getActiveNetwork();
        if (red == null) {
            return false;
        }
        NetworkCapabilities cap = cm.getNetworkCapabilities(red);
        return cap != null && cap.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
    }
}

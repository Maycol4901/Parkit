package com.example.proyecto_app;

import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import android.app.ProgressDialog;

import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class RegistroEncargado extends AppCompatActivity {

    EditText ed1,ed2,ed3,ed4,ed5,ed6,ed7,ed8;
    Button b1,b2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_registro_encargado);

        ed1 = (EditText) findViewById(R.id.nombre);
        ed2 = (EditText) findViewById(R.id.apellido);
        ed3 = (EditText) findViewById(R.id.dni);
        ed4 = (EditText) findViewById(R.id.telefono);
        ed5 = (EditText) findViewById(R.id.correo);
        ed6 = (EditText) findViewById(R.id.contrasena);
        ed7 = (EditText) findViewById(R.id.confirmar);
        ed8 = (EditText) findViewById(R.id.codigo);
        b1 = (Button) findViewById(R.id.bt1);
        b2 = (Button) findViewById(R.id.bt2);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                insert();
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    public void insert()
    {
        String nombre = ed1.getText().toString().trim();
        String apellido = ed2.getText().toString().trim();
        String dni = ed3.getText().toString().trim();
        String telefono = ed4.getText().toString().trim();
        String correo = ed5.getText().toString().trim();
        String contrasena = ed6.getText().toString();
        String confirmar = ed7.getText().toString();
        String codigo = ed8.getText().toString().trim().toUpperCase();

        ProgressDialog progressDialog =new ProgressDialog(this);
        progressDialog.setMessage("Registrando");

        if (nombre.isEmpty()){
            Toast.makeText(this,"ingrese nombre",Toast.LENGTH_SHORT).show();
        }else if (apellido.isEmpty()){
            Toast.makeText(this,"ingrese apellido",Toast.LENGTH_SHORT).show();
        }else if (dni.length() != 8){
            Toast.makeText(this,"el dni debe tener 8 digitos",Toast.LENGTH_SHORT).show();
        }else if (telefono.length() != 9 || !telefono.startsWith("9")){
            Toast.makeText(this,"el telefono debe tener 9 digitos y empezar con 9",Toast.LENGTH_SHORT).show();
        }else if (!Patterns.EMAIL_ADDRESS.matcher(correo).matches()){
            Toast.makeText(this,"correo invalido",Toast.LENGTH_SHORT).show();
        }else if (contrasena.length() < 8){
            Toast.makeText(this,"la contraseña debe tener minimo 8 caracteres",Toast.LENGTH_SHORT).show();
        }else if (!contrasena.matches(".*[A-Z].*")){
            Toast.makeText(this,"la contraseña debe tener una mayuscula",Toast.LENGTH_SHORT).show();
        }else if (!contrasena.matches(".*[0-9].*")){
            Toast.makeText(this,"la contraseña debe tener un numero",Toast.LENGTH_SHORT).show();
        }else if (!contrasena.equals(confirmar)){
            Toast.makeText(this,"las contraseñas no coinciden",Toast.LENGTH_SHORT).show();
        }else if (codigo.isEmpty()){
            Toast.makeText(this,"ingrese el codigo de autorizacion",Toast.LENGTH_SHORT).show();
        }else {
            progressDialog.show();
            StringRequest request =new StringRequest(Request.Method.POST, Config.URL_REGISTRAR_ENCARGADO,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            progressDialog.dismiss();
                            if (response.trim().equalsIgnoreCase("registro exitoso")) {
                                Toast.makeText(RegistroEncargado.this, "cuenta creada, ya puede iniciar sesion", Toast.LENGTH_SHORT).show();
                                finish();
                            } else {
                                Toast.makeText(RegistroEncargado.this, response.trim(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(RegistroEncargado.this,"no se pudo conectar con el servidor",Toast.LENGTH_SHORT).show();
                    progressDialog.dismiss();
                }
            }
            ){

                @Override
                protected Map<String, String> getParams() throws AuthFailureError {

                    Map<String,String>params=new HashMap<>();
                    params.put("nombre",nombre);
                    params.put("apellido",apellido);
                    params.put("dni",dni);
                    params.put("telefono",telefono);
                    params.put("correo",correo);
                    params.put("contrasena",contrasena);
                    params.put("codigo",codigo);

                    return params;
                }
            };
            RequestQueue requestQueue = Volley.newRequestQueue(RegistroEncargado.this);
            requestQueue.add(request);
        }
    }

}

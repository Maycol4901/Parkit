package com.example.proyecto_app;

import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ControlEspacios extends AppCompatActivity {

    GridView grid1;
    TextView t1,t2;
    Button b1;
    ArrayList<String> espacios_ = new ArrayList<String>();
    ArrayList<EspacioControl> espacios = new ArrayList<>();
    ArrayAdapter arrayAdapter;
    SesionManager sesion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_control_espacios);

        sesion = new SesionManager(this);

        grid1 = (GridView) findViewById(R.id.grid1);
        t1 = (TextView) findViewById(R.id.nombre);
        t2 = (TextView) findViewById(R.id.resumen);
        b1 = (Button) findViewById(R.id.bt1);

        t1.setText(sesion.getUsuario().getNombreEstacionamiento());

        // pinta cada casilla del color de su estado
        arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, espacios_) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                TextView casilla = (TextView) super.getView(position, convertView, parent);
                casilla.setGravity(Gravity.CENTER);
                casilla.setPadding(8, 24, 8, 24);
                casilla.setTextColor(getColor(R.color.parkit_texto));
                String estado = espacios.get(position).getEstado();
                if (estado.equals("disponible")){
                    casilla.setBackgroundResource(R.color.parkit_libre);
                }else if (estado.equals("reservado")){
                    casilla.setBackgroundResource(R.color.parkit_reservado);
                }else {
                    casilla.setBackgroundResource(R.color.parkit_ocupado);
                }
                return casilla;
            }
        };
        grid1.setAdapter(arrayAdapter);

        grid1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                opciones(espacios.get(position));
            }
        });
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        ListarDatos();
    }

    // el cuadro cambia segun el estado: entrada, salida o liberar
    public void opciones(EspacioControl e){
        if (e.getEstado().equals("disponible")){
            Toast.makeText(this, "el espacio " + e.getCodigo() + " esta libre", Toast.LENGTH_SHORT).show();
            return;
        }

        String idReserva = e.getIdReserva();

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Espacio " + e.getCodigo());
        builder.setNeutralButton("Cerrar", null);

        String datos = "Placa: " + e.getPlaca() + "\nConductor: " + e.getConductor() + "\nHorario: " + e.getInicio() + " a " + e.getFin() + "\nMonto: S/ " + e.getMonto();

        if (e.getEstado().equals("ocupado")){
            builder.setMessage(datos + "\nIngreso: " + e.getIngreso());
            builder.setPositiveButton("Registrar salida", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Enviar(Config.URL_REGISTRAR_SALIDA, idReserva, "salida registrada");
                }
            });
        }else {
            if (e.getEstadoReserva().equals("confirmada")){
                builder.setMessage(datos + "\nReserva pagada, esperando su llegada");
                builder.setPositiveButton("Registrar entrada", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Enviar(Config.URL_REGISTRAR_ENTRADA, idReserva, "entrada registrada");
                    }
                });
            }else {
                builder.setMessage(datos + "\nReserva pendiente de pago");
            }
            builder.setNegativeButton("Liberar espacio", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Enviar(Config.URL_LIBERAR_RESERVA, idReserva, "espacio liberado");
                }
            });
        }
        builder.show();
    }

    public void ListarDatos(){

        StringRequest request =new StringRequest(Request.Method.POST, Config.URL_LISTAR_CONTROL_ESPACIOS,
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        espacios_.clear();
                        espacios.clear();
                        int libres = 0;
                        int reservados = 0;
                        int ocupados = 0;
                        try {

                            JSONObject jsonObject =new JSONObject(response);
                            String exito=jsonObject.getString("exito");
                            if (exito.equals("1")){
                                JSONArray jsonArray =jsonObject.getJSONArray("datos");
                                for (int i=0;i<jsonArray.length();i++){
                                    EspacioControl e = EspacioControl.desdeJson(jsonArray.getJSONObject(i));

                                    if (e.getEstado().equals("disponible")){
                                        libres++;
                                    }else if (e.getEstado().equals("reservado")){
                                        reservados++;
                                    }else {
                                        ocupados++;
                                    }
                                    String texto = e.getCodigo() + "\n" + e.getEstado();
                                    if (!e.getPlaca().isEmpty()){
                                        texto = texto + "\n" + e.getPlaca();
                                    }
                                    espacios_.add(texto);
                                    espacios.add(e);
                                }
                            }else {
                                Toast.makeText(ControlEspacios.this, jsonObject.getString("mensaje"), Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        arrayAdapter.notifyDataSetChanged();
                        t2.setText("Libres: " + libres + "   Reservados: " + reservados + "   Ocupados: " + ocupados);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(ControlEspacios.this,"no se pudo conectar con el servidor",Toast.LENGTH_SHORT).show();
            }
        }
        ){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String>params=new HashMap<>();
                params.put("id_usuario",sesion.getUsuario().getId());

                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(ControlEspacios.this);
        requestQueue.add(request);

    }

    // la misma funcion sirve para entrada, salida y liberar, solo cambia la url y la respuesta que esperamos
    public void Enviar(String url, final String idReserva, final String esperado){
        StringRequest request =new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        if (response.equalsIgnoreCase(esperado)) {
                            Toast.makeText(ControlEspacios.this, esperado, Toast.LENGTH_SHORT).show();
                            ListarDatos();
                        } else {
                            Toast.makeText(ControlEspacios.this, response, Toast.LENGTH_LONG).show();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(ControlEspacios.this,"no se pudo conectar con el servidor",Toast.LENGTH_SHORT).show();

            }
        }
        ){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String>params=new HashMap<>();
                params.put("id_usuario",sesion.getUsuario().getId());
                params.put("id_reserva",idReserva);

                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(ControlEspacios.this);
        requestQueue.add(request);
    }
}

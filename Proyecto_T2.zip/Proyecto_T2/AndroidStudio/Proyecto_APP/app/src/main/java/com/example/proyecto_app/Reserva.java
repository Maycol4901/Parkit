package com.example.proyecto_app;

import org.json.JSONException;
import org.json.JSONObject;

public class Reserva {
    String id;
    String estacionamiento;
    String espacio;
    String placa;
    String fecha;
    String inicio;
    String fin;
    String monto;
    String estado;
    String metodo;

    public Reserva(String id, String estacionamiento, String espacio, String placa, String fecha, String inicio, String fin, String monto, String estado, String metodo) {
        this.id = id;
        this.estacionamiento = estacionamiento;
        this.espacio = espacio;
        this.placa = placa;
        this.fecha = fecha;
        this.inicio = inicio;
        this.fin = fin;
        this.monto = monto;
        this.estado = estado;
        this.metodo = metodo;
    }

    public Reserva() {
    }

    // convierte el json del php en un objeto
    public static Reserva desdeJson(JSONObject o) throws JSONException {
        return new Reserva(
                o.getString("id_reserva"),
                o.getString("estacionamiento"),
                o.getString("espacio"),
                o.getString("placa"),
                o.getString("fecha"),
                o.getString("hora_inicio"),
                o.getString("hora_fin"),
                o.getString("monto"),
                o.getString("estado"),
                o.getString("metodo"));
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEstacionamiento() {
        return estacionamiento;
    }

    public void setEstacionamiento(String estacionamiento) {
        this.estacionamiento = estacionamiento;
    }

    public String getEspacio() {
        return espacio;
    }

    public void setEspacio(String espacio) {
        this.espacio = espacio;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getInicio() {
        return inicio;
    }

    public void setInicio(String inicio) {
        this.inicio = inicio;
    }

    public String getFin() {
        return fin;
    }

    public void setFin(String fin) {
        this.fin = fin;
    }

    public String getMonto() {
        return monto;
    }

    public void setMonto(String monto) {
        this.monto = monto;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getMetodo() {
        return metodo;
    }

    public void setMetodo(String metodo) {
        this.metodo = metodo;
    }
}

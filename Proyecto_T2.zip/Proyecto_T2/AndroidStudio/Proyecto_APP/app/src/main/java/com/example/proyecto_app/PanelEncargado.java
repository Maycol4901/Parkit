package com.example.proyecto_app;

import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class PanelEncargado extends AppCompatActivity {

    TextView t1,t2;
    Button b1,b2,b3;
    SesionManager sesion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_panel_encargado);

        sesion = new SesionManager(this);

        t1 = (TextView) findViewById(R.id.saludo);
        t2 = (TextView) findViewById(R.id.estacionamiento);
        b1 = (Button) findViewById(R.id.bt1);
        b2 = (Button) findViewById(R.id.bt2);
        b3 = (Button) findViewById(R.id.bt3);

        t1.setText("Hola, " + sesion.getUsuario().getNombre());

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), MiEstacionamiento.class);
                startActivity(i);
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), ControlEspacios.class);
                startActivity(i);
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sesion.cerrar();
                Intent i = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(i);
                finish();
            }
        });
    }

    // por si cambio el nombre del estacionamiento en la otra pantalla
    @Override
    protected void onResume() {
        super.onResume();
        t2.setText("Estacionamiento a cargo: " + sesion.getUsuario().getNombreEstacionamiento());
    }
}

package com.example.proyecto_app;

import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Notificaciones extends AppCompatActivity {

    ListView lst1;
    TextView t1;
    Button b1;
    ArrayList<String> notificaciones_ = new ArrayList<String>();
    ArrayAdapter arrayAdapter;
    SesionManager sesion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_notificaciones);

        sesion = new SesionManager(this);

        lst1 = (ListView) findViewById(R.id.lst1);
        t1 = (TextView) findViewById(R.id.vacio);
        b1 = (Button) findViewById(R.id.bt1);

        arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, notificaciones_);
        lst1.setAdapter(arrayAdapter);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        ListarDatos();
    }

    // las nuevas llevan un punto; al abrir la lista el php las marca como leidas
    public void ListarDatos(){

        StringRequest request =new StringRequest(Request.Method.POST, Config.URL_LISTAR_NOTIFICACIONES,
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        notificaciones_.clear();
                        try {

                            JSONObject jsonObject =new JSONObject(response);
                            String exito=jsonObject.getString("exito");
                            JSONArray jsonArray =jsonObject.getJSONArray("datos");
                            if (exito.equals("1")){
                                for (int i=0;i<jsonArray.length();i++){
                                    JSONObject object=jsonArray.getJSONObject(i);
                                    String titulo=object.getString("titulo");
                                    String mensaje=object.getString("mensaje");
                                    String fecha=object.getString("fecha");
                                    String leida=object.getString("leida");

                                    String marca = "";
                                    if (leida.equals("0")){
                                        marca = "• ";
                                    }
                                    notificaciones_.add(marca + titulo + "\n" + mensaje + "\n" + fecha);
                                }
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        arrayAdapter.notifyDataSetChanged();
                        if (notificaciones_.isEmpty()){
                            t1.setVisibility(View.VISIBLE);
                        }else {
                            t1.setVisibility(View.GONE);
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Notificaciones.this,"no se pudo conectar con el servidor",Toast.LENGTH_SHORT).show();
            }
        }
        ){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String>params=new HashMap<>();
                params.put("id_usuario",sesion.getUsuario().getId());

                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(Notificaciones.this);
        requestQueue.add(request);

    }
}

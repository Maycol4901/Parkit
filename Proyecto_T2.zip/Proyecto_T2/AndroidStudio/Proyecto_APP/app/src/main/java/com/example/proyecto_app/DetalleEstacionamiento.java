package com.example.proyecto_app;

import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class DetalleEstacionamiento extends AppCompatActivity {

    TextView t1,t2,t3,t4,t5,t6;
    Button b1,b2;
    String id;
    Estacionamiento actual;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_detalle_estacionamiento);

        t1 = (TextView) findViewById(R.id.nombre);
        t2 = (TextView) findViewById(R.id.direccion);
        t3 = (TextView) findViewById(R.id.distrito);
        t4 = (TextView) findViewById(R.id.horario);
        t5 = (TextView) findViewById(R.id.tarifa);
        t6 = (TextView) findViewById(R.id.espacios);
        b1 = (Button) findViewById(R.id.bt1);
        b2 = (Button) findViewById(R.id.bt2);

        id = getIntent().getStringExtra("id");

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (actual == null){
                    Toast.makeText(DetalleEstacionamiento.this, "espere a que carguen los datos", Toast.LENGTH_SHORT).show();
                    return;
                }
                Intent i = new Intent(getApplicationContext(), EspaciosEstacionamiento.class);
                i.putExtra("id", actual.getId());
                i.putExtra("nombre", actual.getNombre());
                i.putExtra("tarifa", actual.getTarifa());
                startActivity(i);
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    // se carga de nuevo al volver porque los libres pueden haber cambiado
    @Override
    protected void onResume() {
        super.onResume();
        Cargar();
    }

    public void Cargar(){
        StringRequest request =new StringRequest(Request.Method.POST, Config.URL_OBTENER_ESTACIONAMIENTO,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject json = new JSONObject(response);
                            if (json.getString("exito").equals("1")){
                                Estacionamiento e = Estacionamiento.desdeJson(json.getJSONObject("estacionamiento"));
                                actual = e;
                                t1.setText(e.getNombre());
                                t2.setText("Dirección: " + e.getDireccion());
                                t3.setText("Distrito: " + e.getDistrito());
                                t4.setText("Horario: " + e.getApertura() + " a " + e.getCierre());
                                t5.setText("Tarifa: S/ " + e.getTarifa() + " por hora");
                                t6.setText("Espacios libres: " + e.getDisponibles() + " de " + e.getTotal());
                            }else {
                                Toast.makeText(DetalleEstacionamiento.this, json.getString("mensaje"), Toast.LENGTH_SHORT).show();
                            }
                        } catch (Exception e) {
                            Toast.makeText(DetalleEstacionamiento.this, "error en la respuesta del servidor", Toast.LENGTH_SHORT).show();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(DetalleEstacionamiento.this,"no se pudo conectar con el servidor",Toast.LENGTH_SHORT).show();
            }
        }
        ){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String>params=new HashMap<>();
                params.put("id_estacionamiento",id);

                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(DetalleEstacionamiento.this);
        requestQueue.add(request);
    }
}

package com.example.proyecto_app;

import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ListarVehiculos extends AppCompatActivity {

    ListView lst1;
    TextView t1;
    Button b1,b2;
    ArrayList<String> vehiculos_ = new ArrayList<String>();
    public static ArrayList<Vehiculo> vehiculos = new ArrayList<>();
    ArrayAdapter arrayAdapter;
    SesionManager sesion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_listar_vehiculos);

        sesion = new SesionManager(this);

        lst1 = (ListView) findViewById(R.id.lst1);
        t1 = (TextView) findViewById(R.id.vacio);
        b1 = (Button) findViewById(R.id.bt1);
        b2 = (Button) findViewById(R.id.bt2);

        arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, vehiculos_);
        lst1.setAdapter(arrayAdapter);

        lst1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                preguntarEliminar(position);
            }
        });
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), RegistrarVehiculo.class);
                startActivity(i);
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    // recarga la lista cada vez que se entra a la pantalla
    @Override
    protected void onResume() {
        super.onResume();
        ListarDatos();
    }

    public void ListarDatos(){

        StringRequest request =new StringRequest(Request.Method.POST, Config.URL_LISTAR_VEHICULOS,
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        vehiculos_.clear();
                        vehiculos.clear();
                        try {

                            JSONObject jsonObject =new JSONObject(response);
                            String exito=jsonObject.getString("exito");
                            JSONArray jsonArray =jsonObject.getJSONArray("datos");
                            if (exito.equals("1")){
                                for (int i=0;i<jsonArray.length();i++){
                                    JSONObject object=jsonArray.getJSONObject(i);
                                    String id=object.getString("id_vehiculo");
                                    String placa=object.getString("placa");
                                    String marca=object.getString("marca");
                                    String modelo=object.getString("modelo");
                                    String color=object.getString("color");
                                    String tipo=object.getString("tipo");

                                    vehiculos_.add(placa + "   " + marca + " " + modelo + "\n" + color + "  -  " + tipo);
                                    vehiculos.add(new Vehiculo(id,placa,marca,modelo,color,tipo));
                                }
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        arrayAdapter.notifyDataSetChanged();
                        if (vehiculos.isEmpty()){
                            t1.setVisibility(View.VISIBLE);
                        }else {
                            t1.setVisibility(View.GONE);
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(ListarVehiculos.this,"no se pudo conectar con el servidor",Toast.LENGTH_SHORT).show();
            }
        }
        ){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String>params=new HashMap<>();
                params.put("id_usuario",sesion.getUsuario().getId());

                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(ListarVehiculos.this);
        requestQueue.add(request);

    }

    public void preguntarEliminar(int position){
        String id = vehiculos.get(position).getId();

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Eliminar vehiculo");
        builder.setMessage("Desea eliminar el vehiculo " + vehiculos.get(position).getPlaca() + "?");
        builder.setPositiveButton("Eliminar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Eliminar(id);
            }
        });
        builder.setNegativeButton("Cancelar", null);
        builder.show();
    }

    public  void Eliminar(final  String id){
        StringRequest request =new StringRequest(Request.Method.POST, Config.URL_ELIMINAR_VEHICULO,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        if (response.equalsIgnoreCase("datos eliminados")) {
                            Toast.makeText(ListarVehiculos.this, "elimino correctamente", Toast.LENGTH_SHORT).show();
                            ListarDatos();
                        } else {
                            Toast.makeText(ListarVehiculos.this, "no se pudo eliminar", Toast.LENGTH_SHORT).show();

                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(ListarVehiculos.this,"no se pudo conectar con el servidor",Toast.LENGTH_SHORT).show();

            }
        }
        ){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String>params=new HashMap<>();
                params.put("id_vehiculo",id);
                params.put("id_usuario",sesion.getUsuario().getId());

                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(ListarVehiculos.this);
        requestQueue.add(request);

    }
}

package com.example.proyecto_app;

import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import android.app.ProgressDialog;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class MiEstacionamiento extends AppCompatActivity {

    EditText ed1,ed2,ed3,ed4,ed5,ed6;
    TextView t1;
    Button b1,b2;
    SesionManager sesion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_mi_estacionamiento);

        sesion = new SesionManager(this);

        ed1 = (EditText) findViewById(R.id.nombre);
        ed2 = (EditText) findViewById(R.id.direccion);
        ed3 = (EditText) findViewById(R.id.tarifa);
        ed4 = (EditText) findViewById(R.id.apertura);
        ed5 = (EditText) findViewById(R.id.cierre);
        ed6 = (EditText) findViewById(R.id.total);
        t1 = (TextView) findViewById(R.id.info);
        b1 = (Button) findViewById(R.id.bt1);
        b2 = (Button) findViewById(R.id.bt2);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Update();
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        if (sesion.getUsuario().getIdEstacionamiento().equals("0")){
            Toast.makeText(this,"no tiene un estacionamiento asignado",Toast.LENGTH_SHORT).show();
            b1.setEnabled(false);
        }else {
            Cargar();
        }
    }

    public void Cargar(){
        StringRequest request =new StringRequest(Request.Method.POST, Config.URL_OBTENER_ESTACIONAMIENTO,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject json = new JSONObject(response);
                            if (json.getString("exito").equals("1")){
                                Estacionamiento e = Estacionamiento.desdeJson(json.getJSONObject("estacionamiento"));
                                t1.setText("Distrito: " + e.getDistrito());
                                ed1.setText(e.getNombre());
                                ed2.setText(e.getDireccion());
                                ed3.setText(e.getTarifa());
                                ed4.setText(e.getApertura());
                                ed5.setText(e.getCierre());
                                ed6.setText(e.getTotal());
                            }else {
                                Toast.makeText(MiEstacionamiento.this, json.getString("mensaje"), Toast.LENGTH_SHORT).show();
                            }
                        } catch (Exception e) {
                            Toast.makeText(MiEstacionamiento.this, "error en la respuesta del servidor", Toast.LENGTH_SHORT).show();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MiEstacionamiento.this,"no se pudo conectar con el servidor",Toast.LENGTH_SHORT).show();
            }
        }
        ){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String>params=new HashMap<>();
                params.put("id_estacionamiento",sesion.getUsuario().getIdEstacionamiento());

                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(MiEstacionamiento.this);
        requestQueue.add(request);
    }

    public void Update()
    {
        String nombre = ed1.getText().toString().trim();
        String direccion = ed2.getText().toString().trim();
        String tarifa = ed3.getText().toString().trim();
        String apertura = ed4.getText().toString().trim();
        String cierre = ed5.getText().toString().trim();
        String total = ed6.getText().toString().trim();
        String id_usuario = sesion.getUsuario().getId();

        ProgressDialog progressDialog =new ProgressDialog(this);
        progressDialog.setMessage("Actualizando");

        if (nombre.isEmpty()){
            Toast.makeText(this,"ingrese nombre",Toast.LENGTH_SHORT).show();
        }else if (direccion.isEmpty()){
            Toast.makeText(this,"ingrese direccion",Toast.LENGTH_SHORT).show();
        }else if (!tarifa.matches("[0-9]+(\\.[0-9]{1,2})?")){
            Toast.makeText(this,"ingrese una tarifa valida, ejemplo 6.50",Toast.LENGTH_SHORT).show();
        }else if (!apertura.matches("([01][0-9]|2[0-3]):[0-5][0-9]")){
            Toast.makeText(this,"la hora de apertura debe tener el formato HH:MM, ejemplo 06:00",Toast.LENGTH_SHORT).show();
        }else if (!cierre.matches("([01][0-9]|2[0-3]):[0-5][0-9]")){
            Toast.makeText(this,"la hora de cierre debe tener el formato HH:MM, ejemplo 22:00",Toast.LENGTH_SHORT).show();
        }else if (!total.matches("[0-9]{1,3}") || Integer.parseInt(total) < 1 || Integer.parseInt(total) > 200){
            Toast.makeText(this,"la cantidad de espacios debe estar entre 1 y 200",Toast.LENGTH_SHORT).show();
        }else {
            progressDialog.show();
            StringRequest request =new StringRequest(Request.Method.POST, Config.URL_ACTUALIZAR_ESTACIONAMIENTO,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            progressDialog.dismiss();
                            if (response.trim().equalsIgnoreCase("datos actualizados")) {
                                Toast.makeText(MiEstacionamiento.this, "actualizo correctamente", Toast.LENGTH_SHORT).show();
                                sesion.actualizarEstacionamiento(nombre);
                                finish();
                            } else {
                                Toast.makeText(MiEstacionamiento.this, response.trim(), Toast.LENGTH_LONG).show();
                            }
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(MiEstacionamiento.this,"no se pudo conectar con el servidor",Toast.LENGTH_SHORT).show();
                    progressDialog.dismiss();
                }
            }
            ){

                @Override
                protected Map<String, String> getParams() throws AuthFailureError {

                    Map<String,String>params=new HashMap<>();
                    params.put("id_usuario",id_usuario);
                    params.put("nombre",nombre);
                    params.put("direccion",direccion);
                    params.put("tarifa_hora",tarifa);
                    params.put("hora_apertura",apertura);
                    params.put("hora_cierre",cierre);
                    params.put("total_espacios",total);

                    return params;
                }
            };
            RequestQueue requestQueue = Volley.newRequestQueue(MiEstacionamiento.this);
            requestQueue.add(request);
        }
    }

}

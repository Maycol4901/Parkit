package com.example.proyecto_app;

import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import android.app.ProgressDialog;

import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.content.Intent;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    EditText ed1,ed2;
    Button b1,b2,b3;
    SesionManager sesion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        sesion = new SesionManager(this);
        // si ya habia iniciado sesion se va directo a su panel
        if (sesion.haySesion()){
            irAlPanel(sesion.getUsuario().getRol());
            return;
        }

        ed1 = (EditText) findViewById(R.id.correo);
        ed2 = (EditText) findViewById(R.id.contrasena);
        b1 = (Button) findViewById(R.id.bt1);
        b2 = (Button) findViewById(R.id.bt2);
        b3 = (Button) findViewById(R.id.bt3);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login();
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), RegistroConductor.class);
                startActivity(i);
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), RegistroEncargado.class);
                startActivity(i);
            }
        });
    }

    public void login()
    {
        String correo = ed1.getText().toString().trim();
        String contrasena = ed2.getText().toString();

        ProgressDialog progressDialog =new ProgressDialog(this);
        progressDialog.setMessage("Ingresando");

        if (correo.isEmpty()){
            Toast.makeText(this,"ingrese correo",Toast.LENGTH_SHORT).show();
        }else if (!Patterns.EMAIL_ADDRESS.matcher(correo).matches()){
            Toast.makeText(this,"correo invalido",Toast.LENGTH_SHORT).show();
        }else if (contrasena.isEmpty()){
            Toast.makeText(this,"ingrese contraseña",Toast.LENGTH_SHORT).show();
        }else {
            progressDialog.show();
            StringRequest request =new StringRequest(Request.Method.POST, Config.URL_LOGIN,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            progressDialog.dismiss();
                            try {
                                JSONObject json = new JSONObject(response);
                                if (json.getString("exito").equals("1")){
                                    JSONObject u = json.getJSONObject("usuario");
                                    Usuario usuario = new Usuario(u.getString("id_usuario"),
                                            u.getString("nombre"),
                                            u.getString("apellido"),
                                            u.getString("correo"),
                                            u.getString("rol"),
                                            u.getString("id_estacionamiento"),
                                            u.getString("nombre_estacionamiento"));
                                    sesion.guardar(usuario);
                                    irAlPanel(usuario.getRol());
                                }else {
                                    Toast.makeText(MainActivity.this, json.getString("mensaje"), Toast.LENGTH_SHORT).show();
                                }
                            } catch (Exception e) {
                                Toast.makeText(MainActivity.this, "error en la respuesta del servidor", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(MainActivity.this,"no se pudo conectar con el servidor",Toast.LENGTH_SHORT).show();
                    progressDialog.dismiss();
                }
            }
            ){

                @Override
                protected Map<String, String> getParams() throws AuthFailureError {

                    Map<String,String>params=new HashMap<>();
                    params.put("correo",correo);
                    params.put("contrasena",contrasena);

                    return params;
                }
            };
            RequestQueue requestQueue = Volley.newRequestQueue(MainActivity.this);
            requestQueue.add(request);
        }
    }

    public void irAlPanel(String rol)
    {
        Intent i;
        if (rol.equals("encargado")){
            i = new Intent(getApplicationContext(), PanelEncargado.class);
        }else {
            i = new Intent(getApplicationContext(), PanelConductor.class);
        }
        startActivity(i);
        finish();
    }

}

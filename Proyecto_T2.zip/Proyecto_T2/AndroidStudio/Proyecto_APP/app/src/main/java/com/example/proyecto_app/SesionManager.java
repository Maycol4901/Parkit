package com.example.proyecto_app;

import android.content.Context;
import android.content.SharedPreferences;

public class SesionManager {

    SharedPreferences sp;

    public SesionManager(Context context) {
        sp = context.getSharedPreferences("sesion", Context.MODE_PRIVATE);
    }

    public void guardar(Usuario u) {
        SharedPreferences.Editor editor = sp.edit();
        editor.putString("id", u.getId());
        editor.putString("nombre", u.getNombre());
        editor.putString("apellido", u.getApellido());
        editor.putString("correo", u.getCorreo());
        editor.putString("rol", u.getRol());
        editor.putString("idEstacionamiento", u.getIdEstacionamiento());
        editor.putString("nombreEstacionamiento", u.getNombreEstacionamiento());
        editor.apply();
    }

    public boolean haySesion() {
        return sp.getString("id", null) != null;
    }

    public Usuario getUsuario() {
        return new Usuario(
                sp.getString("id", ""),
                sp.getString("nombre", ""),
                sp.getString("apellido", ""),
                sp.getString("correo", ""),
                sp.getString("rol", ""),
                sp.getString("idEstacionamiento", "0"),
                sp.getString("nombreEstacionamiento", ""));
    }

    public void actualizarEstacionamiento(String nombre) {
        sp.edit().putString("nombreEstacionamiento", nombre).apply();
    }

    public void cerrar() {
        sp.edit().clear().apply();
    }
}

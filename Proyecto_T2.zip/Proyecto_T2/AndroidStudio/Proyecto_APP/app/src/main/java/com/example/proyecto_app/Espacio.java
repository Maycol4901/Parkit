package com.example.proyecto_app;


public class Espacio {
    String id;
    String codigo;
    String estado;

    public Espacio(String id, String codigo, String estado) {
        this.id = id;
        this.codigo = codigo;
        this.estado = estado;
    }

    public Espacio() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}

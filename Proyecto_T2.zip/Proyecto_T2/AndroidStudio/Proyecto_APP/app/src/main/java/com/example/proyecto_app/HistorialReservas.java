package com.example.proyecto_app;

import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class HistorialReservas extends AppCompatActivity {

    ListView lst1;
    TextView t1;
    Button b1;
    ArrayList<String> reservas_ = new ArrayList<String>();
    ArrayList<Reserva> reservas = new ArrayList<>();
    ArrayAdapter arrayAdapter;
    SesionManager sesion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_historial_reservas);

        sesion = new SesionManager(this);

        lst1 = (ListView) findViewById(R.id.lst1);
        t1 = (TextView) findViewById(R.id.vacio);
        b1 = (Button) findViewById(R.id.bt1);

        arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, reservas_);
        lst1.setAdapter(arrayAdapter);

        lst1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent i = new Intent(getApplicationContext(), ConfirmarReserva.class);
                i.putExtra("id_reserva", reservas.get(position).getId());
                startActivity(i);
            }
        });
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    // recarga la lista cada vez que se entra a la pantalla
    @Override
    protected void onResume() {
        super.onResume();
        ListarDatos();
    }

    public void ListarDatos(){

        StringRequest request =new StringRequest(Request.Method.POST, Config.URL_LISTAR_RESERVAS,
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        reservas_.clear();
                        reservas.clear();
                        try {

                            JSONObject jsonObject =new JSONObject(response);
                            String exito=jsonObject.getString("exito");
                            JSONArray jsonArray =jsonObject.getJSONArray("datos");
                            if (exito.equals("1")){
                                for (int i=0;i<jsonArray.length();i++){
                                    Reserva r = Reserva.desdeJson(jsonArray.getJSONObject(i));

                                    reservas_.add(r.getEstacionamiento() + "  -  espacio " + r.getEspacio() + "\n" + r.getFecha() + "  " + r.getInicio() + " a " + r.getFin() + "\nS/ " + r.getMonto() + "  -  " + r.getEstado());
                                    reservas.add(r);
                                }
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        arrayAdapter.notifyDataSetChanged();
                        if (reservas.isEmpty()){
                            t1.setVisibility(View.VISIBLE);
                        }else {
                            t1.setVisibility(View.GONE);
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(HistorialReservas.this,"no se pudo conectar con el servidor",Toast.LENGTH_SHORT).show();
            }
        }
        ){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String>params=new HashMap<>();
                params.put("id_usuario",sesion.getUsuario().getId());

                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(HistorialReservas.this);
        requestQueue.add(request);

    }
}

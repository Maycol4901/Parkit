package com.example.proyecto_app;

public class Config {

    // la ip del servidor se cambia solo aqui (10.0.2.2 es la del emulador)
    public static final String BASE_URL = "http://10.0.2.2/parkit_api/";

    // un php por tabla, y despues del ? va lo que queremos hacer (insertar, listar...)

    // usuarios.php
    public static final String URL_LOGIN = BASE_URL + "usuarios.php?accion=login";
    public static final String URL_REGISTRAR_CONDUCTOR = BASE_URL + "usuarios.php?accion=insertar_conductor";
    public static final String URL_REGISTRAR_ENCARGADO = BASE_URL + "usuarios.php?accion=insertar_encargado";

    // vehiculos.php
    public static final String URL_REGISTRAR_VEHICULO = BASE_URL + "vehiculos.php?accion=insertar";
    public static final String URL_LISTAR_VEHICULOS = BASE_URL + "vehiculos.php?accion=listar";
    public static final String URL_ELIMINAR_VEHICULO = BASE_URL + "vehiculos.php?accion=eliminar";

    // estacionamientos.php
    public static final String URL_LISTAR_ESTACIONAMIENTOS = BASE_URL + "estacionamientos.php?accion=listar";
    public static final String URL_OBTENER_ESTACIONAMIENTO = BASE_URL + "estacionamientos.php?accion=obtener";
    public static final String URL_ACTUALIZAR_ESTACIONAMIENTO = BASE_URL + "estacionamientos.php?accion=actualizar";

    // espacios.php
    public static final String URL_LISTAR_ESPACIOS = BASE_URL + "espacios.php?accion=listar";
    public static final String URL_LISTAR_CONTROL_ESPACIOS = BASE_URL + "espacios.php?accion=control";

    // reservas.php
    public static final String URL_REGISTRAR_RESERVA = BASE_URL + "reservas.php?accion=insertar";
    public static final String URL_LISTAR_RESERVAS = BASE_URL + "reservas.php?accion=listar";
    public static final String URL_OBTENER_RESERVA = BASE_URL + "reservas.php?accion=obtener";
    public static final String URL_CONFIRMAR_RESERVA = BASE_URL + "reservas.php?accion=confirmar";
    public static final String URL_CANCELAR_RESERVA = BASE_URL + "reservas.php?accion=cancelar";
    public static final String URL_LISTAR_METODOS_PAGO = BASE_URL + "reservas.php?accion=metodos";

    // movimientos.php
    public static final String URL_REGISTRAR_ENTRADA = BASE_URL + "movimientos.php?accion=entrada";
    public static final String URL_REGISTRAR_SALIDA = BASE_URL + "movimientos.php?accion=salida";
    public static final String URL_LIBERAR_RESERVA = BASE_URL + "movimientos.php?accion=liberar";

    // notificaciones.php
    public static final String URL_LISTAR_NOTIFICACIONES = BASE_URL + "notificaciones.php?accion=listar";
}

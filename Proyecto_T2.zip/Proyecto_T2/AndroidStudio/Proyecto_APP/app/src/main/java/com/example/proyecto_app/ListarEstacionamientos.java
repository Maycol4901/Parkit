package com.example.proyecto_app;

import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Marker;

import java.util.HashMap;
import java.util.Map;

public class ListarEstacionamientos extends AppCompatActivity {

    EditText ed1;
    Button b1,b2,b3;
    TextView t1;
    ListView lst1;
    ArrayList<String> estacionamientos_ = new ArrayList<String>();
    ArrayList<Estacionamiento> estacionamientos = new ArrayList<>();
    ArrayAdapter arrayAdapter;
    MapView mapa;
    Estacionamiento ultimo;

    @Override
    protected void onResume() {
        super.onResume();
        mapa.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        mapa.onPause();
    }

    // pone en el mapa los mismos estacionamientos de la lista (y el punto de busqueda si fue Cerca de mi)
    public void ActualizarMapa(String latitud, String longitud){
        mapa.getOverlays().clear();
        ultimo = null;

        for (int i=0;i<estacionamientos.size();i++){
            Estacionamiento e = estacionamientos.get(i);

            Marker marcador = new Marker(mapa);
            marcador.setPosition(new GeoPoint(Double.parseDouble(e.getLatitud()), Double.parseDouble(e.getLongitud())));
            marcador.setTitle(e.getNombre());
            marcador.setSnippet("S/ " + e.getTarifa() + " por hora - toca otra vez para ver el detalle");
            marcador.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
            marcador.setOnMarkerClickListener(new Marker.OnMarkerClickListener() {
                @Override
                public boolean onMarkerClick(Marker marker, MapView mapView) {
                    if (ultimo != null && ultimo.getId().equals(e.getId())){
                        Intent intento = new Intent(getApplicationContext(), DetalleEstacionamiento.class);
                        intento.putExtra("id", e.getId());
                        startActivity(intento);
                    }else {
                        ultimo = e;
                        marker.showInfoWindow();
                        mapView.getController().animateTo(marker.getPosition());
                    }
                    return true;
                }
            });
            mapa.getOverlays().add(marcador);
        }

        if (!latitud.isEmpty()){
            GeoPoint punto = new GeoPoint(Double.parseDouble(latitud), Double.parseDouble(longitud));
            Marker yo = new Marker(mapa);
            yo.setPosition(punto);
            yo.setTitle("Punto de busqueda");
            yo.setIcon(getDrawable(android.R.drawable.ic_menu_mylocation));
            yo.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER);
            mapa.getOverlays().add(yo);
            mapa.getController().setZoom(14.0);
            mapa.getController().animateTo(punto);
        }else {
            mapa.getController().setZoom(13.0);
            mapa.getController().animateTo(new GeoPoint(Ubicacion.LIMA_LATITUD, Ubicacion.LIMA_LONGITUD));
        }
        mapa.invalidate();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        Ubicacion.iniciarMapa(this);
        setContentView(R.layout.activity_listar_estacionamientos);

        mapa = (MapView) findViewById(R.id.mapa);
        Ubicacion.prepararMapa(this, mapa, 13.0);

        ed1 = (EditText) findViewById(R.id.busqueda);
        b1 = (Button) findViewById(R.id.bt1);
        b2 = (Button) findViewById(R.id.bt2);
        b3 = (Button) findViewById(R.id.bt3);
        t1 = (TextView) findViewById(R.id.vacio);
        lst1 = (ListView) findViewById(R.id.lst1);

        arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, estacionamientos_);
        lst1.setAdapter(arrayAdapter);

        ListarDatos("", "");

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ListarDatos("", "");
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cercaDeMi();
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        lst1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent i = new Intent(getApplicationContext(), DetalleEstacionamiento.class);
                i.putExtra("id", estacionamientos.get(position).getId());
                startActivity(i);
            }
        });
    }

    // cuando ya hay ubicacion (o Lima de respaldo) busca los cercanos
    Ubicacion.Resultado resultado = new Ubicacion.Resultado() {
        @Override
        public void listo(double latitud, double longitud, boolean real) {
            ListarDatos(String.valueOf(latitud), String.valueOf(longitud));
        }
    };

    public void cercaDeMi()
    {
        if (Ubicacion.tienePermiso(this)){
            Ubicacion.obtener(this, resultado);
        }else {
            Ubicacion.pedirPermiso(this);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == Ubicacion.PERMISO) {
            if (Ubicacion.tienePermiso(this)) {
                Ubicacion.obtener(this, resultado);
            } else {
                Ubicacion.usarLima(this, "sin permiso de ubicacion, se usa Lima como referencia", resultado);
            }
        }
    }

    // si mandamos latitud y longitud trae solo los de menos de 10 km
    public void ListarDatos(String latitud, String longitud){

        String busqueda = ed1.getText().toString().trim();
        boolean conUbicacion = !latitud.isEmpty();

        StringRequest request =new StringRequest(Request.Method.POST, Config.URL_LISTAR_ESTACIONAMIENTOS,
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        estacionamientos_.clear();
                        estacionamientos.clear();
                        try {

                            JSONObject jsonObject =new JSONObject(response);
                            String exito=jsonObject.getString("exito");
                            JSONArray jsonArray =jsonObject.getJSONArray("datos");
                            if (exito.equals("1")){
                                for (int i=0;i<jsonArray.length();i++){
                                    Estacionamiento e = Estacionamiento.desdeJson(jsonArray.getJSONObject(i));

                                    String texto = e.getNombre() + "\n" + e.getDistrito() + " - " + e.getDireccion() + "\nS/ " + e.getTarifa() + " por hora  -  " + e.getDisponibles() + " libres";
                                    if (!e.getDistancia().isEmpty()){
                                        texto = texto + "   (a " + e.getDistancia() + " km)";
                                    }
                                    estacionamientos_.add(texto);
                                    estacionamientos.add(e);
                                }
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        arrayAdapter.notifyDataSetChanged();
                        ActualizarMapa(latitud, longitud);

                        if (estacionamientos.isEmpty()){
                            if (conUbicacion){
                                t1.setText("No hay estacionamientos a menos de 10 km de su ubicacion");
                            }else {
                                t1.setText("No se encontraron estacionamientos");
                            }
                            t1.setVisibility(View.VISIBLE);
                        }else {
                            t1.setVisibility(View.GONE);
                            if (conUbicacion){
                                Toast.makeText(ListarEstacionamientos.this, "estacionamientos a menos de 10 km", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(ListarEstacionamientos.this,"no se pudo conectar con el servidor",Toast.LENGTH_SHORT).show();
            }
        }
        ){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String>params=new HashMap<>();
                params.put("busqueda",busqueda);
                params.put("latitud",latitud);
                params.put("longitud",longitud);

                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(ListarEstacionamientos.this);
        requestQueue.add(request);

    }
}

package com.example.proyecto_app;

import org.json.JSONException;
import org.json.JSONObject;

public class Estacionamiento {
    String id;
    String nombre;
    String direccion;
    String distrito;
    String latitud;
    String longitud;
    String tarifa;
    String apertura;
    String cierre;
    String total;
    String disponibles;
    String distancia;

    public Estacionamiento(String id, String nombre, String direccion, String distrito, String latitud, String longitud, String tarifa, String apertura, String cierre, String total, String disponibles, String distancia) {
        this.id = id;
        this.nombre = nombre;
        this.direccion = direccion;
        this.distrito = distrito;
        this.latitud = latitud;
        this.longitud = longitud;
        this.tarifa = tarifa;
        this.apertura = apertura;
        this.cierre = cierre;
        this.total = total;
        this.disponibles = disponibles;
        this.distancia = distancia;
    }

    public Estacionamiento() {
    }

    // convierte el json del php en un objeto
    public static Estacionamiento desdeJson(JSONObject o) throws JSONException {
        String disponibles = "0";
        if (o.has("disponibles")) {
            disponibles = o.getString("disponibles");
        }
        String distancia = "";
        if (o.has("distancia")) {
            distancia = o.getString("distancia");
        }
        return new Estacionamiento(
                o.getString("id_estacionamiento"),
                o.getString("nombre"),
                o.getString("direccion"),
                o.getString("distrito"),
                o.getString("latitud"),
                o.getString("longitud"),
                o.getString("tarifa_hora"),
                o.getString("hora_apertura"),
                o.getString("hora_cierre"),
                o.getString("total_espacios"),
                disponibles,
                distancia);
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getDistrito() {
        return distrito;
    }

    public void setDistrito(String distrito) {
        this.distrito = distrito;
    }

    public String getLatitud() {
        return latitud;
    }

    public void setLatitud(String latitud) {
        this.latitud = latitud;
    }

    public String getLongitud() {
        return longitud;
    }

    public void setLongitud(String longitud) {
        this.longitud = longitud;
    }

    public String getTarifa() {
        return tarifa;
    }

    public void setTarifa(String tarifa) {
        this.tarifa = tarifa;
    }

    public String getApertura() {
        return apertura;
    }

    public void setApertura(String apertura) {
        this.apertura = apertura;
    }

    public String getCierre() {
        return cierre;
    }

    public void setCierre(String cierre) {
        this.cierre = cierre;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public String getDisponibles() {
        return disponibles;
    }

    public void setDisponibles(String disponibles) {
        this.disponibles = disponibles;
    }

    public String getDistancia() {
        return distancia;
    }

    public void setDistancia(String distancia) {
        this.distancia = distancia;
    }
}

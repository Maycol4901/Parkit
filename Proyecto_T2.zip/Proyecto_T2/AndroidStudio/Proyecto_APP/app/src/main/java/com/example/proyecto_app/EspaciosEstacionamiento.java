package com.example.proyecto_app;

import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class EspaciosEstacionamiento extends AppCompatActivity {

    GridView grid1;
    TextView t1,t2;
    Button b1;
    ArrayList<String> espacios_ = new ArrayList<String>();
    ArrayList<Espacio> espacios = new ArrayList<>();
    ArrayAdapter arrayAdapter;
    String id,nombre,tarifa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_espacios_estacionamiento);

        grid1 = (GridView) findViewById(R.id.grid1);
        t1 = (TextView) findViewById(R.id.nombre);
        t2 = (TextView) findViewById(R.id.resumen);
        b1 = (Button) findViewById(R.id.bt1);

        id = getIntent().getStringExtra("id");
        nombre = getIntent().getStringExtra("nombre");
        tarifa = getIntent().getStringExtra("tarifa");
        t1.setText(nombre);

        // pinta cada casilla del color de su estado
        arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, espacios_) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                TextView casilla = (TextView) super.getView(position, convertView, parent);
                casilla.setGravity(android.view.Gravity.CENTER);
                casilla.setPadding(8, 24, 8, 24);
                casilla.setTextColor(getColor(R.color.parkit_texto));
                String estado = espacios.get(position).getEstado();
                if (estado.equals("disponible")){
                    casilla.setBackgroundResource(R.color.parkit_libre);
                }else if (estado.equals("reservado")){
                    casilla.setBackgroundResource(R.color.parkit_reservado);
                }else {
                    casilla.setBackgroundResource(R.color.parkit_ocupado);
                }
                return casilla;
            }
        };
        grid1.setAdapter(arrayAdapter);

        grid1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long idItem) {
                Espacio e = espacios.get(position);
                if (e.getEstado().equals("disponible")){
                    Intent i = new Intent(getApplicationContext(), Reservar.class);
                    i.putExtra("nombre", nombre);
                    i.putExtra("tarifa", tarifa);
                    i.putExtra("id_espacio", e.getId());
                    i.putExtra("codigo", e.getCodigo());
                    startActivity(i);
                }else {
                    Toast.makeText(EspaciosEstacionamiento.this, "el espacio " + e.getCodigo() + " no esta disponible", Toast.LENGTH_SHORT).show();
                }
            }
        });
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    // recarga al volver de reservar
    @Override
    protected void onResume() {
        super.onResume();
        ListarDatos();
    }

    public void ListarDatos(){

        StringRequest request =new StringRequest(Request.Method.POST, Config.URL_LISTAR_ESPACIOS,
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        espacios_.clear();
                        espacios.clear();
                        int libres = 0;
                        try {

                            JSONObject jsonObject =new JSONObject(response);
                            String exito=jsonObject.getString("exito");
                            JSONArray jsonArray =jsonObject.getJSONArray("datos");
                            if (exito.equals("1")){
                                for (int i=0;i<jsonArray.length();i++){
                                    JSONObject object=jsonArray.getJSONObject(i);
                                    String idEspacio=object.getString("id_espacio");
                                    String codigo=object.getString("codigo");
                                    String estado=object.getString("estado");

                                    if (estado.equals("disponible")){
                                        libres++;
                                    }
                                    espacios_.add(codigo + "\n" + estado);
                                    espacios.add(new Espacio(idEspacio,codigo,estado));
                                }
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        arrayAdapter.notifyDataSetChanged();
                        t2.setText("Libres: " + libres + " de " + espacios.size() + "   -   S/ " + tarifa + " por hora");
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(EspaciosEstacionamiento.this,"no se pudo conectar con el servidor",Toast.LENGTH_SHORT).show();
            }
        }
        ){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String>params=new HashMap<>();
                params.put("id_estacionamiento",id);

                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(EspaciosEstacionamiento.this);
        requestQueue.add(request);

    }
}

package com.example.proyecto_app;

import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Reservar extends AppCompatActivity {

    TextView t1,t2,t3,t4;
    Spinner s1,s2;
    Button b1,b2;
    ArrayList<String> vehiculos_ = new ArrayList<String>();
    ArrayList<Vehiculo> vehiculos = new ArrayList<>();
    ArrayAdapter arrayAdapter;
    SesionManager sesion;
    String idEspacio,codigo,tarifa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_reservar);

        sesion = new SesionManager(this);

        t1 = (TextView) findViewById(R.id.nombre);
        t2 = (TextView) findViewById(R.id.espacio);
        t3 = (TextView) findViewById(R.id.tarifa);
        t4 = (TextView) findViewById(R.id.total);
        s1 = (Spinner) findViewById(R.id.vehiculo);
        s2 = (Spinner) findViewById(R.id.horas);
        b1 = (Button) findViewById(R.id.bt1);
        b2 = (Button) findViewById(R.id.bt2);

        idEspacio = getIntent().getStringExtra("id_espacio");
        codigo = getIntent().getStringExtra("codigo");
        tarifa = getIntent().getStringExtra("tarifa");

        t1.setText(getIntent().getStringExtra("nombre"));
        t2.setText("Espacio: " + codigo);
        t3.setText("Tarifa: S/ " + tarifa + " por hora");

        arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, vehiculos_);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s1.setAdapter(arrayAdapter);

        s2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                CalcularTotal();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Guardar();
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        CalcularTotal();
        ListarVehiculos();
    }

    public void CalcularTotal()
    {
        int horas = Integer.parseInt(s2.getSelectedItem().toString());
        double total = Double.parseDouble(tarifa) * horas;
        t4.setText("Total: S/ " + String.format("%.2f", total));
    }

    public void ListarVehiculos(){

        StringRequest request =new StringRequest(Request.Method.POST, Config.URL_LISTAR_VEHICULOS,
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        vehiculos_.clear();
                        vehiculos.clear();
                        try {

                            JSONObject jsonObject =new JSONObject(response);
                            String exito=jsonObject.getString("exito");
                            JSONArray jsonArray =jsonObject.getJSONArray("datos");
                            if (exito.equals("1")){
                                for (int i=0;i<jsonArray.length();i++){
                                    JSONObject object=jsonArray.getJSONObject(i);
                                    String id=object.getString("id_vehiculo");
                                    String placa=object.getString("placa");
                                    String marca=object.getString("marca");
                                    String modelo=object.getString("modelo");
                                    String color=object.getString("color");
                                    String tipo=object.getString("tipo");

                                    vehiculos_.add(placa + "  -  " + marca + " " + modelo);
                                    vehiculos.add(new Vehiculo(id,placa,marca,modelo,color,tipo));
                                }
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        arrayAdapter.notifyDataSetChanged();
                        if (vehiculos.isEmpty()){
                            Toast.makeText(Reservar.this,"primero registre un vehiculo",Toast.LENGTH_LONG).show();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Reservar.this,"no se pudo conectar con el servidor",Toast.LENGTH_SHORT).show();
            }
        }
        ){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String>params=new HashMap<>();
                params.put("id_usuario",sesion.getUsuario().getId());

                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(Reservar.this);
        requestQueue.add(request);

    }

    public void Guardar()
    {
        if (vehiculos.isEmpty()){
            Toast.makeText(this,"primero registre un vehiculo",Toast.LENGTH_SHORT).show();
            return;
        }

        String idVehiculo = vehiculos.get(s1.getSelectedItemPosition()).getId();
        String horas = s2.getSelectedItem().toString();

        ProgressDialog progressDialog =new ProgressDialog(this);
        progressDialog.setMessage("Reservando");
        progressDialog.show();

        StringRequest request =new StringRequest(Request.Method.POST, Config.URL_REGISTRAR_RESERVA,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();
                        try {
                            JSONObject json = new JSONObject(response);
                            if (json.getString("exito").equals("1")) {
                                Intent i = new Intent(getApplicationContext(), ConfirmarReserva.class);
                                i.putExtra("id_reserva", json.getString("id_reserva"));
                                startActivity(i);
                                finish();
                            } else {
                                Toast.makeText(Reservar.this, json.getString("mensaje"), Toast.LENGTH_LONG).show();
                            }
                        } catch (JSONException e) {
                            Toast.makeText(Reservar.this, "error en la respuesta del servidor", Toast.LENGTH_SHORT).show();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(Reservar.this,"no se pudo conectar con el servidor",Toast.LENGTH_SHORT).show();

            }
        }
        ){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String>params=new HashMap<>();
                params.put("id_usuario",sesion.getUsuario().getId());
                params.put("id_vehiculo",idVehiculo);
                params.put("id_espacio",idEspacio);
                params.put("horas",horas);

                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(Reservar.this);
        requestQueue.add(request);
    }
}

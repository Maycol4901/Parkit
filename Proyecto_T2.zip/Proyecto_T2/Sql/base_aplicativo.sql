-- =====================================================
-- PARKIT - Base de datos: base_aplicativo (MySQL, puerto 3307)
-- Importar desde phpMyAdmin > Importar
-- Contrasena de TODOS los usuarios de prueba: Parkit123
-- =====================================================
DROP DATABASE IF EXISTS base_aplicativo;
CREATE DATABASE base_aplicativo CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE base_aplicativo;

CREATE TABLE usuarios (
  id_usuario INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(60) NOT NULL,
  apellido VARCHAR(60) NOT NULL,
  dni CHAR(8) NOT NULL UNIQUE,
  telefono CHAR(9) NOT NULL,
  correo VARCHAR(100) NOT NULL UNIQUE,
  contrasena VARCHAR(255) NOT NULL,
  rol ENUM('conductor','encargado') NOT NULL,
  fecha_registro DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE vehiculos (
  id_vehiculo INT AUTO_INCREMENT PRIMARY KEY,
  id_usuario INT NOT NULL,
  placa VARCHAR(7) NOT NULL UNIQUE,
  marca VARCHAR(40) NOT NULL,
  modelo VARCHAR(40) NOT NULL,
  color VARCHAR(30) NOT NULL,
  tipo ENUM('auto','camioneta','moto') NOT NULL,
  FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE estacionamientos (
  id_estacionamiento INT AUTO_INCREMENT PRIMARY KEY,
  id_encargado INT NULL,
  nombre VARCHAR(80) NOT NULL,
  direccion VARCHAR(150) NOT NULL,
  distrito VARCHAR(50) NOT NULL,
  latitud DECIMAL(10,7) NOT NULL,
  longitud DECIMAL(10,7) NOT NULL,
  tarifa_hora DECIMAL(6,2) NOT NULL,
  hora_apertura TIME NOT NULL,
  hora_cierre TIME NOT NULL,
  total_espacios INT NOT NULL,
  FOREIGN KEY (id_encargado) REFERENCES usuarios(id_usuario) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE codigos_encargado (
  id_codigo INT AUTO_INCREMENT PRIMARY KEY,
  id_estacionamiento INT NOT NULL,
  codigo VARCHAR(12) NOT NULL UNIQUE,
  usado TINYINT(1) NOT NULL DEFAULT 0,
  fecha_generacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  fecha_vencimiento DATETIME NOT NULL,
  fecha_uso DATETIME NULL,
  FOREIGN KEY (id_estacionamiento) REFERENCES estacionamientos(id_estacionamiento) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE espacios (
  id_espacio INT AUTO_INCREMENT PRIMARY KEY,
  id_estacionamiento INT NOT NULL,
  codigo VARCHAR(10) NOT NULL,
  estado ENUM('disponible','ocupado','reservado') NOT NULL DEFAULT 'disponible',
  UNIQUE KEY uq_espacio (id_estacionamiento, codigo),
  FOREIGN KEY (id_estacionamiento) REFERENCES estacionamientos(id_estacionamiento) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE metodos_pago (
  id_metodo INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(30) NOT NULL,
  activo TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE reservas (
  id_reserva INT AUTO_INCREMENT PRIMARY KEY,
  id_usuario INT NOT NULL,
  id_vehiculo INT NOT NULL,
  id_espacio INT NOT NULL,
  id_metodo INT NULL,
  fecha_reserva DATE NOT NULL,
  hora_inicio TIME NOT NULL,
  hora_fin TIME NOT NULL,
  monto DECIMAL(8,2) NOT NULL,
  estado ENUM('pendiente','confirmada','en_curso','finalizada','cancelada') NOT NULL DEFAULT 'pendiente',
  fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario),
  FOREIGN KEY (id_vehiculo) REFERENCES vehiculos(id_vehiculo),
  FOREIGN KEY (id_espacio) REFERENCES espacios(id_espacio),
  FOREIGN KEY (id_metodo) REFERENCES metodos_pago(id_metodo)
) ENGINE=InnoDB;

CREATE TABLE movimientos (
  id_movimiento INT AUTO_INCREMENT PRIMARY KEY,
  id_espacio INT NOT NULL,
  id_vehiculo INT NOT NULL,
  id_reserva INT NULL,
  hora_ingreso DATETIME NOT NULL,
  hora_salida DATETIME NULL,
  FOREIGN KEY (id_espacio) REFERENCES espacios(id_espacio),
  FOREIGN KEY (id_vehiculo) REFERENCES vehiculos(id_vehiculo),
  FOREIGN KEY (id_reserva) REFERENCES reservas(id_reserva)
) ENGINE=InnoDB;

CREATE TABLE notificaciones (
  id_notificacion INT AUTO_INCREMENT PRIMARY KEY,
  id_usuario INT NOT NULL,
  titulo VARCHAR(80) NOT NULL,
  mensaje VARCHAR(255) NOT NULL,
  tipo VARCHAR(30) NOT NULL,
  leida TINYINT(1) NOT NULL DEFAULT 0,
  fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ================= DATOS DE PRUEBA =================
INSERT INTO metodos_pago (nombre) VALUES ('Efectivo'),('Yape'),('Plin'),('Tarjeta');

-- Estacionamientos de prueba en Los Olivos y alrededores (coordenadas aproximadas).
-- Los crea el administrador; id_encargado queda NULL hasta usar el codigo
INSERT INTO estacionamientos (nombre,direccion,distrito,latitud,longitud,tarifa_hora,hora_apertura,hora_cierre,total_espacios) VALUES
('Parkit Mendiola','Av. Alfredo Mendiola 3500','Los Olivos',-11.9990000,-77.0668000,5.00,'06:00','23:00',10),
('Parkit Izaguirre','Av. Carlos Izaguirre 800','Los Olivos',-11.9880000,-77.0690000,6.00,'00:00','23:59',12),
('Parkit Universitaria','Av. Universitaria 6200','Los Olivos',-11.9770000,-77.0810000,4.50,'07:00','22:00',12),
('Parkit Las Palmeras','Av. Las Palmeras 3100','Los Olivos',-11.9680000,-77.0760000,4.00,'06:00','23:00',8),
('Parkit Naranjal','Av. Naranjal 1200','Independencia',-11.9960000,-77.0540000,5.00,'06:00','22:00',10),
('Parkit Tomas Valle','Av. Tomas Valle 2200','San Martin de Porres',-12.0080000,-77.0680000,4.00,'07:00','21:00',8);

-- Codigos de autorizacion (1 por estacionamiento, vencen en 7 dias)
INSERT INTO codigos_encargado (id_estacionamiento,codigo,fecha_vencimiento) VALUES
(1,'PKT-4821',DATE_ADD(NOW(),INTERVAL 7 DAY)),
(2,'PKT-7305',DATE_ADD(NOW(),INTERVAL 7 DAY)),
(3,'PKT-1958',DATE_ADD(NOW(),INTERVAL 7 DAY)),
(4,'PKT-6642',DATE_ADD(NOW(),INTERVAL 7 DAY)),
(5,'PKT-3079',DATE_ADD(NOW(),INTERVAL 7 DAY)),
(6,'PKT-8814',DATE_ADD(NOW(),INTERVAL 7 DAY));

-- Espacios
INSERT INTO espacios (id_estacionamiento,codigo,estado) VALUES
(1,'A-01','disponible'),
(1,'A-02','ocupado'),
(1,'A-03','disponible'),
(1,'A-04','disponible'),
(1,'A-05','ocupado'),
(1,'A-06','disponible'),
(1,'A-07','ocupado'),
(1,'A-08','disponible'),
(1,'A-09','disponible'),
(1,'A-10','disponible'),
(2,'A-01','ocupado'),
(2,'A-02','ocupado'),
(2,'A-03','ocupado'),
(2,'A-04','ocupado'),
(2,'A-05','ocupado'),
(2,'A-06','ocupado'),
(2,'A-07','ocupado'),
(2,'A-08','ocupado'),
(2,'A-09','ocupado'),
(2,'A-10','ocupado'),
(2,'A-11','ocupado'),
(2,'A-12','ocupado'),
(3,'A-01','ocupado'),
(3,'A-02','disponible'),
(3,'A-03','ocupado'),
(3,'A-04','ocupado'),
(3,'A-05','disponible'),
(3,'A-06','disponible'),
(3,'A-07','disponible'),
(3,'A-08','ocupado'),
(3,'A-09','ocupado'),
(3,'A-10','disponible'),
(3,'A-11','disponible'),
(3,'A-12','disponible'),
(4,'A-01','disponible'),
(4,'A-02','ocupado'),
(4,'A-03','disponible'),
(4,'A-04','disponible'),
(4,'A-05','disponible'),
(4,'A-06','disponible'),
(4,'A-07','disponible'),
(4,'A-08','disponible'),
(5,'A-01','ocupado'),
(5,'A-02','ocupado'),
(5,'A-03','disponible'),
(5,'A-04','disponible'),
(5,'A-05','disponible'),
(5,'A-06','ocupado'),
(5,'A-07','disponible'),
(5,'A-08','disponible'),
(5,'A-09','disponible'),
(5,'A-10','disponible'),
(6,'A-01','disponible'),
(6,'A-02','disponible'),
(6,'A-03','disponible'),
(6,'A-04','disponible'),
(6,'A-05','disponible'),
(6,'A-06','disponible'),
(6,'A-07','disponible'),
(6,'A-08','disponible');

-- Usuarios de prueba (contrasena: Parkit123)
INSERT INTO usuarios (nombre,apellido,dni,telefono,correo,contrasena,rol) VALUES
('Carlos','Mendoza','45871236','987654321','carlos@parkit.com','$2y$10$yQ.EEIEkW8vOjyKw3mwnbuWVRhCphRNX0vf3HSo60IziPOmHxapsu','encargado'),
('Lucia','Ramos','41236587','976543210','lucia@parkit.com','$2y$10$yQ.EEIEkW8vOjyKw3mwnbuWVRhCphRNX0vf3HSo60IziPOmHxapsu','encargado'),
('Andrea','Torres','72145896','965432109','andrea@parkit.com','$2y$10$yQ.EEIEkW8vOjyKw3mwnbuWVRhCphRNX0vf3HSo60IziPOmHxapsu','conductor'),
('Jose','Quispe','70125478','954321098','jose@parkit.com','$2y$10$yQ.EEIEkW8vOjyKw3mwnbuWVRhCphRNX0vf3HSo60IziPOmHxapsu','conductor');

-- Encargados de prueba ya vinculados (consumen los codigos de los estacionamientos 1 y 2)
UPDATE estacionamientos SET id_encargado=1 WHERE id_estacionamiento=1;
UPDATE estacionamientos SET id_encargado=2 WHERE id_estacionamiento=2;
UPDATE codigos_encargado SET usado=1, fecha_uso=NOW() WHERE id_estacionamiento IN (1,2);

INSERT INTO vehiculos (id_usuario,placa,marca,modelo,color,tipo) VALUES
(3,'ABC123','Toyota','Yaris','Blanco','auto'),
(4,'XYZ789','Hyundai','Tucson','Gris','camioneta');
